# src/app.py
import sys
from pathlib import Path


_ROOT = Path(__file__).resolve().parents[1]

if str(_ROOT) not in sys.path:

    sys.path.insert(0, str(_ROOT))

import customtkinter as ctk

from src.app_controller import AppController
from src.ui import theme as T
from src.ui.assistant_view import AssistantView
from src.ui.home_view import HomeView
from src.ui.import_dialog import ImportDialog
from src.ui.profile_view import ProfileView
from src.ui.progress_view import ProgressView
from src.ui.quiz_view import QuizView


class App(ctk.CTk):

    def __init__(self):

        super().__init__()

        ctk.set_appearance_mode("dark")

        ctk.set_default_color_theme("dark-blue")


        self.controller = AppController()

        self.configure(fg_color=T.BG_DEEP)


        self.title("Student Study Buddy System")

        self.geometry("1080x740")

        self.minsize(940, 660)

        self.active_import_dialog: ctk.CTkToplevel | None = None
        self.banner_frame: ctk.CTkFrame | None = None
        self.banner_status_lbl: ctk.CTkLabel | None = None
        self.banner_restore_btn: ctk.CTkButton | None = None

        self.grid_columnconfigure(0, weight=1)

        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)


        self.container = ctk.CTkFrame(self, fg_color=T.BG_DEEP)

        self.container.grid(row=0, column=0, sticky="nsew")

        self.container.grid_columnconfigure(0, weight=1)

        self.container.grid_rowconfigure(0, weight=1)


        self.views: dict[str, ctk.CTkFrame] = {}

        self._show_home()

    def register_import_dialog(self, dialog: ctk.CTkToplevel) -> None:
        self.active_import_dialog = dialog

    def unregister_import_dialog(self, dialog: ctk.CTkToplevel) -> None:
        if self.active_import_dialog == dialog:
            self.active_import_dialog = None
            self.hide_bg_import_banner()

    def open_import_dialog(self, controller, on_complete, initial_mode: str = "upload") -> None:
        if self.active_import_dialog and self.active_import_dialog.winfo_exists():
            if getattr(self.active_import_dialog, "is_minimized", False):
                self.active_import_dialog.restore()
            else:
                self.active_import_dialog.lift()
                self.active_import_dialog.focus_force()
            return

        dialog = ImportDialog(self, controller, on_complete, initial_mode=initial_mode)
        self.active_import_dialog = dialog

    def show_bg_import_banner(self, dialog: ctk.CTkToplevel) -> None:
        if not self.banner_frame:
            self.banner_frame = ctk.CTkFrame(
                self,
                fg_color=T.BG_CARD,
                border_width=1,
                border_color=T.ACCENT_BLUE,
                corner_radius=T.CORNER_RADIUS_SM,
                height=48,
            )
            self.banner_frame.grid_columnconfigure(1, weight=1)

            # Left icon / indicator
            ctk.CTkLabel(
                self.banner_frame,
                text="⚡",
                font=ctk.CTkFont(size=16),
                text_color=T.ACCENT_BLUE,
            ).grid(row=0, column=0, padx=(16, 8), pady=10)

            self.banner_status_lbl = ctk.CTkLabel(
                self.banner_frame,
                text="Generating quiz in background...",
                font=T.FONT_BODY,
                text_color=T.TEXT_PRIMARY,
                anchor="w",
            )
            self.banner_status_lbl.grid(row=0, column=1, sticky="w", padx=4)

            self.banner_restore_btn = ctk.CTkButton(
                self.banner_frame,
                text="🔍 Expand / Restore",
                width=140,
                height=32,
                corner_radius=16,
                fg_color=T.ACCENT_BLUE,
                hover_color=T.ACCENT_PURPLE,
                text_color=T.TEXT_PRIMARY,
                font=T.FONT_SMALL,
                command=dialog.restore,
            )
            self.banner_restore_btn.grid(row=0, column=2, padx=(8, 16), pady=8)
        else:
            self.banner_restore_btn.configure(command=dialog.restore)

        self.banner_frame.grid(row=1, column=0, sticky="ew", padx=24, pady=(0, 16))

    def update_bg_import_progress(self, text: str) -> None:
        if self.banner_status_lbl:
            self.banner_status_lbl.configure(text=text)

    def hide_bg_import_banner(self) -> None:
        if self.banner_frame:
            self.banner_frame.grid_forget()


    def _clear_views(self) -> None:

        for child in self.container.winfo_children():

            child.destroy()

        self.views.clear()


    def _show_home(self) -> None:

        self._clear_views()

        view = HomeView(
            self.container,
            controller=self.controller,
            on_assistant=self._show_assistant,
            on_quiz=self._show_quiz,
            on_progress=self._show_progress,
            on_profile=self._show_profile,
        )

        view.grid(row=0, column=0, sticky="nsew")

        self.views["home"] = view


    def _show_assistant(self) -> None:

        self._clear_views()

        view = AssistantView(
            self.container,
            controller=self.controller,
            on_back=self._show_home,
        )

        view.grid(row=0, column=0, sticky="nsew")

        self.views["assistant"] = view


    def _show_quiz(self) -> None:

        self._clear_views()

        view = QuizView(
            self.container,
            controller=self.controller,
            on_back=self._show_home,
        )

        view.grid(row=0, column=0, sticky="nsew")

        self.views["quiz"] = view


    def _show_progress(self) -> None:

        self._clear_views()

        view = ProgressView(
            self.container,
            controller=self.controller,
            on_back=self._show_home,
        )

        view.grid(row=0, column=0, sticky="nsew")

        self.views["progress"] = view


    def _show_profile(self) -> None:

        self._clear_views()

        view = ProfileView(
            self.container,
            controller=self.controller,
            on_back=self._show_home,
        )

        view.grid(row=0, column=0, sticky="nsew")

        self.views["profile"] = view


    def run(self) -> None:

        self.mainloop()


if __name__ == "__main__":

    App().run()
