# src/ui/import_dialog.py
import threading
import customtkinter as ctk
from tkinter import messagebox

from src.ui import theme as T
from src.ui.widgets import GradientButton, LoadingDots


class ImportDialog(ctk.CTkToplevel):

    def __init__(self, master, controller, on_complete, initial_mode: str = "upload", **kwargs):

        super().__init__(master, **kwargs)

        self.controller = controller
        self.on_complete = on_complete
        self._generating = False
        self._loaded_path: str | None = None
        self.is_minimized = False

        self.app = master.winfo_toplevel()
        if hasattr(self.app, "register_import_dialog"):
            self.app.register_import_dialog(self)

        self.title("Import Study Materials")
        self.geometry("540x550")
        self.configure(fg_color=T.BG_DEEP)
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()

        self.protocol("WM_DELETE_WINDOW", self._on_close_attempt)

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Header Frame with Title & Minimize Button
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, padx=24, pady=(16, 4), sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            header_frame,
            text="Import Study Materials",
            font=T.FONT_HEADING,
            text_color=T.TEXT_PRIMARY,
        ).grid(row=0, column=0, sticky="w")

        self.min_btn_hdr = ctk.CTkButton(
            header_frame,
            text="➖ Minimize",
            width=90,
            height=28,
            corner_radius=14,
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.TEXT_SECONDARY,
            font=T.FONT_SMALL,
            command=self.minimize,
        )
        self.min_btn_hdr.grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(
            self,
            text="Choose your source material to generate an AI study quiz.",
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
        ).grid(row=1, column=0, padx=24, pady=(0, 12), sticky="w")

        # Tabview for Multi-Source Import
        self.tabview = ctk.CTkTabview(
            self,
            fg_color=T.BG_CARD,
            segmented_button_fg_color=T.BG_OPTION,
            segmented_button_selected_color=T.ACCENT_BLUE,
            segmented_button_selected_hover_color=T.ACCENT_PURPLE,
            segmented_button_unselected_color=T.BG_OPTION,
            segmented_button_unselected_hover_color=T.BG_CARD,
            text_color=T.TEXT_PRIMARY,
        )
        self.tabview.grid(row=2, column=0, sticky="nsew", padx=24, pady=(0, 8))

        # Add Tabs
        self.tab_upload = self.tabview.add("📄 Upload File")
        self.tab_paste = self.tabview.add("📋 Paste Text")

        self._build_upload_tab()
        self._build_paste_tab()

        # Set active tab
        if initial_mode == "paste":
            self.tabview.set("📋 Paste Text")
        else:
            self.tabview.set("📄 Upload File")

        # Preferences entry
        self.pref_entry = ctk.CTkEntry(
            self,
            placeholder_text="Preferences (e.g. Focus on definitions, multiple choice...)",
            font=T.FONT_BODY,
            fg_color=T.BG_CARD,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
        )
        self.pref_entry.grid(row=3, column=0, sticky="ew", padx=24, pady=(4, 8))

        self.status = ctk.CTkLabel(
            self,
            text="",
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
        )
        self.status.grid(row=4, column=0, padx=24, sticky="w")

        self.loader = LoadingDots(self, text="Generating quiz")
        self.loader.grid(row=5, column=0, padx=24, sticky="w")

        self.gen_btn = GradientButton(
            self,
            text="Import & Generate Quiz",
            command=self._import_and_generate,
        )
        self.gen_btn.grid(row=6, column=0, padx=24, pady=(8, 8), sticky="ew")

        # Dynamic Minimize to Background Button during generation
        self.min_bg_btn = ctk.CTkButton(
            self,
            text="📥 Minimize to Background",
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.ACCENT_BLUE,
            font=T.FONT_BODY,
            height=36,
            command=self.minimize,
        )

    def _build_upload_tab(self) -> None:
        self.tab_upload.grid_columnconfigure(0, weight=1)
        self.tab_upload.grid_rowconfigure(0, weight=1)

        frame = ctk.CTkFrame(self.tab_upload, fg_color="transparent")
        frame.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)
        frame.grid_columnconfigure(0, weight=1)

        self.file_lbl = ctk.CTkLabel(
            frame,
            text="No file selected yet",
            font=T.FONT_BODY,
            text_color=T.TEXT_MUTED,
            wraplength=400,
        )
        self.file_lbl.pack(pady=(20, 16))

        ctk.CTkButton(
            frame,
            text="Browse PDF / TXT",
            fg_color=T.ACCENT_BLUE,
            hover_color=T.ACCENT_PURPLE,
            text_color=T.TEXT_PRIMARY,
            height=40,
            command=self._browse,
        ).pack()

    def _build_paste_tab(self) -> None:
        self.tab_paste.grid_columnconfigure(0, weight=1)
        self.tab_paste.grid_rowconfigure(0, weight=1)

        self.paste_box = ctk.CTkTextbox(
            self.tab_paste,
            fg_color=T.BG_DEEP,
            border_color=T.BORDER,
            border_width=1,
            text_color=T.TEXT_PRIMARY,
            font=T.FONT_BODY,
        )
        self.paste_box.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)

    def _browse(self) -> None:
        path = self.controller.open_file()
        if path:
            self._loaded_path = path
            import os
            self.file_lbl.configure(text=f"Loaded: {os.path.basename(path)}", text_color=T.TEXT_PRIMARY)
            self.status.configure(text=f"Loaded file: {os.path.basename(path)}")

    def minimize(self) -> None:
        """Minimize dialog and release modal grab to allow app exploration."""
        self.is_minimized = True
        self.grab_release()
        self.withdraw()
        if hasattr(self.app, "show_bg_import_banner"):
            self.app.show_bg_import_banner(self)

    def restore(self) -> None:
        """Restore dialog window to focus."""
        self.is_minimized = False
        self.deiconify()
        self.lift()
        self.focus_force()
        if hasattr(self.app, "hide_bg_import_banner"):
            self.app.hide_bg_import_banner()

    def _on_close_attempt(self) -> None:
        if self._generating:
            # If quiz generation is running, minimize instead of closing abruptly
            self.minimize()
        else:
            self.destroy()

    def destroy(self) -> None:
        if hasattr(self.app, "unregister_import_dialog"):
            self.app.unregister_import_dialog(self)
        super().destroy()

    def _import_and_generate(self) -> None:
        if self._generating:
            return

        active_tab = self.tabview.get()
        prefs = self.pref_entry.get().strip()

        def load():
            if "Paste" in active_tab:
                pasted = self.paste_box.get("1.0", "end").strip()
                if not pasted:
                    raise ValueError("Paste plain text before generating.")
                self.controller.load_pasted_text(pasted)
                return "Pasted text"
            else:
                if self._loaded_path:
                    return self._loaded_path
                raise ValueError("Browse and select a PDF or TXT file first.")

        def generate():
            source = load()
            total_holder = [0]

            def progress(current, total, preview):
                total_holder[0] = total
                self.after(
                    0,
                    lambda: self._on_progress_update(current, total, preview),
                )

            questions = self.controller.generate_quiz(on_progress=progress, preferences=prefs)
            record = self.controller.save_quiz_to_history(questions)
            return record, total_holder[0]

        self._generating = True
        self.gen_btn.configure(state="disabled")
        self.min_bg_btn.grid(row=7, column=0, padx=24, pady=(0, 16), sticky="ew")
        self.loader.start()

        def runner():
            try:
                result = generate()
                self.after(0, self._done, result)
            except Exception as e:
                self.after(0, self._fail, e)

        threading.Thread(target=runner, daemon=True).start()

    def _on_progress_update(self, current: int, total: int, preview: str) -> None:
        status_msg = f"Chunk {current}/{total}: {preview[:40]}…"
        self.status.configure(text=status_msg)

        if hasattr(self.app, "update_bg_import_progress"):
            banner_msg = f"Generating Quiz ({current}/{total}): {preview[:30]}…"
            self.app.update_bg_import_progress(banner_msg)

    def _done(self, result) -> None:
        record, chunks = result
        self._generating = False
        self.loader.stop()
        self.gen_btn.configure(state="normal")
        self.min_bg_btn.grid_forget()

        if hasattr(self.app, "hide_bg_import_banner"):
            self.app.hide_bg_import_banner()

        was_minimized = self.is_minimized
        self.grab_release()
        self.on_complete(record)
        self.destroy()

        messagebox.showinfo(
            "Quiz ready",
            f"Generated {record['question_count']} questions from {chunks} chunks.",
        )

    def _fail(self, exc) -> None:
        self._generating = False
        self.loader.stop()
        self.gen_btn.configure(state="normal")
        self.min_bg_btn.grid_forget()

        if hasattr(self.app, "hide_bg_import_banner"):
            self.app.hide_bg_import_banner()

        if self.is_minimized:
            self.restore()

        messagebox.showerror("Import failed", str(exc))

