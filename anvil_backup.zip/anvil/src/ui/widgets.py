# src/ui/widgets.py
import customtkinter as ctk

from src.ui import theme as T


import os
from PIL import Image

LOGO_IMAGE_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "logo.png")


class AnvilCanvasIcon(ctk.CTkFrame):
    """System logo widget displaying logo PNG or custom icon."""

    def __init__(self, master, size: int = 36, color: str = T.ACCENT_BLUE, outline: str = "#60A5FA", bg_color: str = "transparent", **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        if os.path.exists(LOGO_IMAGE_PATH):
            try:
                pil_img = Image.open(LOGO_IMAGE_PATH)
                self.ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(size, size))
                lbl = ctk.CTkLabel(self, image=self.ctk_img, text="")
                lbl.pack()
                return
            except Exception:
                pass
        # Fallback badge if image cannot load
        lbl = ctk.CTkLabel(self, text="🎓", font=ctk.CTkFont(size=int(size*0.7)))
        lbl.pack()


class AnvilLogo(ctk.CTkFrame):

    def __init__(self, master, **kwargs):

        super().__init__(master, fg_color="transparent", **kwargs)

        AnvilCanvasIcon(self, size=28).pack(side="left", padx=(0, 10))

        ctk.CTkLabel(
            self,
            text="Student Study Buddy System",
            font=ctk.CTkFont(family="Inter", size=18, weight="bold"),
            text_color=T.ACCENT_BLUE,
        ).pack(side="left")


class LoadingDots(ctk.CTkFrame):
    """Animated three-dot loader for async operations."""


    FRAMES = ["   ", ".  ", ".. ", "..."]


    def __init__(self, master, text: str = "Thinking", **kwargs):

        super().__init__(master, fg_color="transparent", **kwargs)

        self._text = text

        self._frame_idx = 0

        self._job = None

        self.label = ctk.CTkLabel(
            self,
            text=f"{text}{self.FRAMES[0]}",
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
            anchor="w",
        )

        self.label.pack(anchor="w")


    def start(self) -> None:

        self._tick()


    def stop(self) -> None:

        if self._job:

            self.after_cancel(self._job)

            self._job = None

        self.label.configure(text="")


    def _tick(self) -> None:

        self._frame_idx = (self._frame_idx + 1) % len(self.FRAMES)

        self.label.configure(text=f"{self._text}{self.FRAMES[self._frame_idx]}")

        self._job = self.after(400, self._tick)


class GradientButton(ctk.CTkButton):

    def __init__(self, master, **kwargs):

        defaults = dict(
            fg_color=T.ACCENT_BLUE,
            hover_color=T.ACCENT_PURPLE,
            text_color=T.TEXT_PRIMARY,
            font=T.FONT_BODY,
            corner_radius=T.CORNER_RADIUS_SM,
            height=44,
        )

        defaults.update(kwargs)

        super().__init__(master, **defaults)


class ChatBubble(ctk.CTkFrame):

    def __init__(self, master, text: str, is_user: bool = False, **kwargs):

        bg = T.BG_USER_BUBBLE if is_user else "transparent"

        anchor = "e" if is_user else "w"

        super().__init__(master, fg_color="transparent", **kwargs)


        bubble = ctk.CTkFrame(
            self,
            fg_color=bg,
            corner_radius=T.CORNER_RADIUS,
        )

        side = "right" if is_user else "left"

        bubble.pack(side=side, padx=(80 if is_user else 0, 0 if is_user else 80))


        ctk.CTkLabel(
            bubble,
            text=text,
            font=T.FONT_BODY,
            text_color=T.TEXT_PRIMARY,
            wraplength=520,
            justify="left" if not is_user else "right",
        ).pack(padx=16, pady=12, anchor=anchor)
