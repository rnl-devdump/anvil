# src/ui/progress_view.py
import customtkinter as ctk

from src.ui import theme as T
from src.ui.widgets import AnvilLogo, GradientButton


class ProgressView(ctk.CTkFrame):

    def __init__(self, master, controller, on_back, **kwargs):

        super().__init__(master, fg_color=T.BG_DEEP, **kwargs)

        self.controller = controller
        self.on_back = on_back

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()
        self._build_content()

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=32, pady=(24, 12))
        header.grid_columnconfigure(1, weight=1)

        AnvilLogo(header).grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            header,
            text="Learning Progress & Analytics",
            font=T.FONT_HEADING,
            text_color=T.TEXT_PRIMARY,
        ).grid(row=0, column=1)

        ctk.CTkButton(
            header,
            text="← Home",
            width=100,
            height=36,
            corner_radius=18,
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            font=ctk.CTkFont(family="Inter", size=13, weight="bold"),
            command=self.on_back,
        ).grid(row=0, column=2, sticky="e")

    def _build_content(self) -> None:
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.grid(row=1, column=0, sticky="nsew", padx=32, pady=(0, 24))
        scroll.grid_columnconfigure(0, weight=1)

        quizzes = self.controller.quiz_store.all
        total_quizzes = len(quizzes)
        total_questions = sum(q.get("question_count", 0) for q in quizzes)

        scored_quizzes = [q for q in quizzes if "last_score" in q]
        if scored_quizzes:
            avg_score = sum(q["last_score"] for q in scored_quizzes) / len(scored_quizzes)
            mastery_text = f"{avg_score:.1f} / 10"
            pct = int((avg_score / 10.0) * 100)
            mastery_sub = f"{pct}% Overall Mastery"
        else:
            mastery_text = "N/A"
            mastery_sub = "Complete a quiz to track score"

        # Stats Cards Row
        stats_row = ctk.CTkFrame(scroll, fg_color="transparent")
        stats_row.grid(row=0, column=0, sticky="ew", pady=(0, 24))
        stats_row.grid_columnconfigure((0, 1, 2), weight=1)

        self._build_stat_card(stats_row, 0, "🔥 Study Streak", "3 Days", "Keep up the great work!", T.ACCENT_BLUE)
        self._build_stat_card(stats_row, 1, "📚 Total Quizzes", str(total_quizzes), f"{total_questions} Questions Generated", T.ACCENT_BLUE)
        self._build_stat_card(stats_row, 2, "🏆 Average Score", mastery_text, mastery_sub, T.ACCENT_PURPLE)

        # History Breakdown Section
        ctk.CTkLabel(
            scroll,
            text="Recent Quiz History & Scores",
            font=ctk.CTkFont(family="Inter", size=18, weight="bold"),
            text_color=T.TEXT_PRIMARY,
        ).grid(row=1, column=0, sticky="w", pady=(0, 12))

        history_frame = ctk.CTkFrame(scroll, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        history_frame.grid(row=2, column=0, sticky="ew")
        history_frame.grid_columnconfigure(0, weight=1)

        if not quizzes:
            ctk.CTkLabel(
                history_frame,
                text="No study history yet. Complete a quiz to track your progress!",
                font=T.FONT_BODY,
                text_color=T.TEXT_MUTED,
            ).pack(pady=32)
        else:
            for idx, q in enumerate(quizzes):
                item = ctk.CTkFrame(history_frame, fg_color="transparent")
                item.pack(fill="x", padx=16, pady=12)
                item.grid_columnconfigure(0, weight=1)

                ctk.CTkLabel(
                    item,
                    text=q.get("title", "Untitled Quiz"),
                    font=T.FONT_BODY,
                    text_color=T.TEXT_PRIMARY,
                    anchor="w",
                ).grid(row=0, column=0, sticky="w")

                ctk.CTkLabel(
                    item,
                    text=f"{q.get('question_count', 0)} Questions · Created {q.get('created_at', '')[:10]}",
                    font=T.FONT_SMALL,
                    text_color=T.TEXT_SECONDARY,
                    anchor="w",
                ).grid(row=1, column=0, sticky="w")

                # Score pill / badge on right side
                score_val = q.get("last_score")
                if score_val is not None:
                    score_str = f"Score: {score_val:.1f} / 10"
                    color = T.SUCCESS if score_val >= 7.0 else (T.WARNING if score_val >= 5.0 else T.ACCENT_PURPLE)
                else:
                    score_str = "Not Attempted"
                    color = T.TEXT_MUTED

                ctk.CTkLabel(
                    item,
                    text=score_str,
                    font=ctk.CTkFont(family="Inter", size=13, weight="bold"),
                    text_color=color,
                ).grid(row=0, column=1, rowspan=2, sticky="e", padx=8)

                if idx < len(quizzes) - 1:
                    ctk.CTkFrame(history_frame, fg_color=T.BORDER, height=1).pack(fill="x", padx=16)

    def _build_stat_card(self, parent, col, title, value, subtitle, accent_color) -> None:
        card = ctk.CTkFrame(parent, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        card.grid(row=0, column=col, sticky="ew", padx=8)

        ctk.CTkLabel(
            card,
            text=title,
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
        ).pack(anchor="w", padx=16, pady=(16, 4))

        ctk.CTkLabel(
            card,
            text=value,
            font=ctk.CTkFont(family="Inter", size=28, weight="bold"),
            text_color=accent_color,
        ).pack(anchor="w", padx=16)

        ctk.CTkLabel(
            card,
            text=subtitle,
            font=T.FONT_SMALL,
            text_color=T.TEXT_MUTED,
        ).pack(anchor="w", padx=16, pady=(4, 16))
