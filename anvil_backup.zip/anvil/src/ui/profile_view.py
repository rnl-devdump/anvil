# src/ui/profile_view.py
import os
import customtkinter as ctk
from tkinter import simpledialog, filedialog, messagebox
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from src.ui import theme as T
from src.ui.widgets import AnvilLogo


class ProfileView(ctk.CTkFrame):

    def __init__(self, master, controller, on_back, **kwargs):

        super().__init__(master, fg_color=T.BG_DEEP, **kwargs)

        self.controller = controller
        self.on_back = on_back
        self.profile = self.controller.profile_store

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()
        self._build_content()

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=32, pady=(24, 12))
        header.grid_columnconfigure(1, weight=1)

        AnvilLogo(header).grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            header,
            text="Student Profile & Settings",
            font=T.FONT_HEADING,
            text_color=T.TEXT_PRIMARY,
        ).grid(row=0, column=1)

        ctk.CTkButton(
            header,
            text="← Home",
            width=80,
            fg_color="transparent",
            hover_color=T.BG_CARD,
            text_color=T.TEXT_SECONDARY,
            command=self.on_back,
        ).grid(row=0, column=2, sticky="e")

    def _build_content(self) -> None:
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=32, pady=(0, 24))
        self.scroll.grid_columnconfigure(0, weight=1)

        self._render_profile_card()
        self._render_system_card()
        self._render_data_card()

    def _render_profile_card(self) -> None:
        if hasattr(self, "prof_card") and self.prof_card:
            self.prof_card.destroy()

        self.prof_card = ctk.CTkFrame(self.scroll, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        self.prof_card.pack(fill="x", pady=(0, 20))

        inner = ctk.CTkFrame(self.prof_card, fg_color="transparent")
        inner.pack(fill="x", padx=24, pady=20)
        inner.grid_columnconfigure(1, weight=1)

        # Avatar Image or Initials Badge
        avatar_path = self.profile.avatar_path
        if PIL_AVAILABLE and avatar_path and os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(72, 72))
                avatar_widget = ctk.CTkLabel(inner, image=ctk_img, text="")
            except Exception:
                avatar_widget = self._build_initials_avatar(inner)
        else:
            avatar_widget = self._build_initials_avatar(inner)

        avatar_widget.grid(row=0, column=0, rowspan=3, padx=(0, 20), sticky="w")

        # Name and Details
        self.name_lbl = ctk.CTkLabel(
            inner,
            text=self.profile.name,
            font=ctk.CTkFont(family="Inter", size=22, weight="bold"),
            text_color=T.TEXT_PRIMARY,
            anchor="w",
        )
        self.name_lbl.grid(row=0, column=1, sticky="w")

        ctk.CTkLabel(
            inner,
            text=f"Course: {self.profile.course}",
            font=T.FONT_BODY,
            text_color=T.TEXT_SECONDARY,
            anchor="w",
        ).grid(row=1, column=1, sticky="w")

        ctk.CTkLabel(
            inner,
            text=f"Submitted to: {self.profile.instructor}",
            font=T.FONT_SMALL,
            text_color=T.ACCENT_PURPLE,
            anchor="w",
        ).grid(row=2, column=1, sticky="w")

        # Edit Action Buttons
        btn_box = ctk.CTkFrame(inner, fg_color="transparent")
        btn_box.grid(row=0, column=2, rowspan=3, sticky="e")

        ctk.CTkButton(
            btn_box,
            text="✎ Edit Name",
            width=110,
            fg_color=T.BG_OPTION,
            hover_color=T.ACCENT_BLUE,
            text_color=T.TEXT_PRIMARY,
            command=self._change_name,
        ).pack(pady=4)

        ctk.CTkButton(
            btn_box,
            text="🖼 Change Picture",
            width=110,
            fg_color=T.BG_OPTION,
            hover_color=T.ACCENT_PURPLE,
            text_color=T.TEXT_PRIMARY,
            command=self._change_picture,
        ).pack(pady=4)

    def _build_initials_avatar(self, parent) -> ctk.CTkLabel:
        name_parts = [p for p in self.profile.name.split() if p]
        initials = "".join(p[0].upper() for p in name_parts[:2]) if name_parts else "RN"

        return ctk.CTkLabel(
            parent,
            text=initials,
            width=64,
            height=64,
            fg_color=T.ACCENT_BLUE,
            corner_radius=32,
            font=ctk.CTkFont(family="Inter", size=22, weight="bold"),
            text_color=T.TEXT_PRIMARY,
        )

    def _change_name(self) -> None:
        new_name = simpledialog.askstring("Edit Name", "Enter student name:", initialvalue=self.profile.name)
        if new_name and new_name.strip():
            self.profile.name = new_name.strip()
            self._render_profile_card()

    def _change_picture(self) -> None:
        path = filedialog.askopenfilename(
            title="Select Profile Picture",
            filetypes=[
                ("Image files", "*.png;*.jpg;*.jpeg;*.bmp;*.webp"),
                ("All files", "*.*"),
            ]
        )
        if path:
            self.profile.avatar_path = path
            self._render_profile_card()

    def _render_system_card(self) -> None:
        sys_card = ctk.CTkFrame(self.scroll, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        sys_card.pack(fill="x", pady=(0, 20))

        sys_inner = ctk.CTkFrame(sys_card, fg_color="transparent")
        sys_inner.pack(fill="x", padx=24, pady=20)

        ctk.CTkLabel(
            sys_inner,
            text="System & Model Details",
            font=ctk.CTkFont(family="Inter", size=16, weight="bold"),
            text_color=T.TEXT_PRIMARY,
        ).pack(anchor="w", pady=(0, 12))

        from src.core.config import EMBED_MODEL, LLM_MODEL
        self._add_info_row(sys_inner, "Active Text LLM Model:", LLM_MODEL)
        self._add_info_row(sys_inner, "Embedding Model:", EMBED_MODEL)
        self._add_info_row(sys_inner, "PDF Parser Engine:", self.controller.pdf_engine)
        self._add_info_row(sys_inner, "Ollama Backend:", "http://localhost:11434 (Local & Private)")

    def _render_data_card(self) -> None:
        data_card = ctk.CTkFrame(self.scroll, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        data_card.pack(fill="x", pady=(0, 20))

        d_inner = ctk.CTkFrame(data_card, fg_color="transparent")
        d_inner.pack(fill="x", padx=24, pady=20)

        ctk.CTkLabel(
            d_inner,
            text="Data Management",
            font=ctk.CTkFont(family="Inter", size=16, weight="bold"),
            text_color=T.TEXT_PRIMARY,
        ).pack(anchor="w", pady=(0, 8))

        ctk.CTkLabel(
            d_inner,
            text="Clear saved quiz history and embedded document cache.",
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
        ).pack(anchor="w", pady=(0, 12))

        ctk.CTkButton(
            d_inner,
            text="Clear Quiz History",
            fg_color=T.BG_OPTION,
            hover_color=T.ERROR,
            text_color=T.TEXT_PRIMARY,
            command=self._clear_history,
        ).pack(anchor="w")

    def _add_info_row(self, parent, label, val) -> None:
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=4)

        ctk.CTkLabel(
            row,
            text=label,
            font=T.FONT_BODY,
            text_color=T.TEXT_SECONDARY,
            width=180,
            anchor="w",
        ).pack(side="left")

        ctk.CTkLabel(
            row,
            text=val,
            font=T.FONT_BODY,
            text_color=T.TEXT_PRIMARY,
            anchor="w",
        ).pack(side="left")

    def _clear_history(self) -> None:
        if messagebox.askyesno("Clear History", "Are you sure you want to clear all saved quizzes from history?"):
            self.controller.quiz_store.clear()
            messagebox.showinfo("Success", "Quiz history cleared.")
