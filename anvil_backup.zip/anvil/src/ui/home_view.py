# src/ui/home_view.py
import customtkinter as ctk

from src.ui import theme as T
from src.ui.import_dialog import ImportDialog
from src.ui.widgets import AnvilCanvasIcon, AnvilLogo, GradientButton


class HomeView(ctk.CTkFrame):

    def __init__(self, master, controller, on_assistant, on_quiz, on_progress, on_profile=None, **kwargs):

        super().__init__(master, fg_color=T.BG_DEEP, **kwargs)

        self.controller = controller
        self.on_assistant = on_assistant
        self.on_quiz = on_quiz
        self.on_progress = on_progress
        self.on_profile = on_profile

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()
        self._build_main_scrollable()
        self._build_footer()

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=32, pady=(24, 0))
        header.grid_columnconfigure(1, weight=1)

        AnvilLogo(header).pack(side="left")

    def _build_footer(self) -> None:
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.grid(row=2, column=0, sticky="ew", padx=28, pady=(0, 16))
        footer.grid_columnconfigure(1, weight=1)

        # Lower-Left: Course & Submission Credits
        prof = self.controller.profile_store
        credits_frame = ctk.CTkFrame(footer, fg_color="transparent")
        credits_frame.grid(row=0, column=0, sticky="sw")

        ctk.CTkLabel(
            credits_frame,
            text=f"{prof.course}\nSubmitted to: {prof.instructor}\nSubmitted by: {prof.name}",
            font=ctk.CTkFont(family="Inter", size=11),
            text_color=T.TEXT_MUTED,
            justify="left",
            anchor="w",
        ).pack(anchor="w")

        # Lower-Right: Progress & Profile Actions
        actions_frame = ctk.CTkFrame(footer, fg_color="transparent")
        actions_frame.grid(row=0, column=2, sticky="se")

        ctk.CTkButton(
            actions_frame,
            text="🔥 Progress",
            width=110,
            height=36,
            corner_radius=18,
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            font=ctk.CTkFont(family="Inter", size=13, weight="bold"),
            command=self.on_progress,
        ).pack(side="left", padx=5)

        if self.on_profile:
            ctk.CTkButton(
                actions_frame,
                text="👤 Profile",
                width=110,
                height=36,
                corner_radius=18,
                fg_color=T.BG_CARD,
                hover_color=T.BG_OPTION,
                border_width=1,
                border_color=T.BORDER,
                text_color=T.TEXT_PRIMARY,
                font=ctk.CTkFont(family="Inter", size=13, weight="bold"),
                command=self.on_profile,
            ).pack(side="left", padx=5)

    def _build_main_scrollable(self) -> None:
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.grid(row=1, column=0, sticky="nsew", padx=32, pady=(20, 12))
        scroll.grid_columnconfigure(0, weight=1)

        # 1. Centered Hero Header Section (Lowered elements)
        hero = ctk.CTkFrame(scroll, fg_color="transparent")
        hero.pack(fill="x", pady=(32, 24))
        hero.grid_columnconfigure(0, weight=1)

        # System Logo Icon
        AnvilCanvasIcon(hero, size=120).pack(pady=(0, 14))

        # Main Centered Title: Student Study Buddy System
        ctk.CTkLabel(
            hero,
            text="Student Study Buddy System",
            font=ctk.CTkFont(family="Inter", size=36, weight="bold"),
            text_color=T.ACCENT_BLUE,
        ).pack(pady=(0, 2))

        # Centered Subtitle: YOUR PERSONAL AI QUIZ & STUDY SYSTEM
        ctk.CTkLabel(
            hero,
            text="YOUR PERSONAL AI QUIZ & STUDY SYSTEM",
            font=ctk.CTkFont(family="Inter", size=13, weight="bold"),
            text_color=T.ACCENT_PURPLE,
            justify="center",
        ).pack(pady=(0, 12))

        ctk.CTkLabel(
            hero,
            text="Upload study materials or paste notes to generate instant AI quizzes and assistant Q&A.",
            font=T.FONT_BODY,
            text_color=T.TEXT_SECONDARY,
            justify="center",
        ).pack(pady=(0, 28))

        # 2. Main Launcher Buttons (Bigger size: height 56, width 240)
        mode_row = ctk.CTkFrame(hero, fg_color="transparent")
        mode_row.pack(pady=(0, 28))

        GradientButton(
            mode_row,
            text="💬 Assistant Q&A",
            width=240,
            height=56,
            font=ctk.CTkFont(family="Inter", size=17, weight="bold"),
            corner_radius=28,
            command=self.on_assistant,
        ).pack(side="left", padx=12)

        GradientButton(
            mode_row,
            text="⚡ Quiz Me!",
            width=240,
            height=56,
            font=ctk.CTkFont(family="Inter", size=17, weight="bold"),
            corner_radius=28,
            command=self.on_quiz,
        ).pack(side="left", padx=12)

        # 3. Action Buttons (Bigger size: height 46, width 170)
        action_bar = ctk.CTkFrame(hero, fg_color="transparent")
        action_bar.pack(pady=(0, 32))

        ctk.CTkButton(
            action_bar,
            text="📄 Upload File",
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            height=46,
            width=170,
            corner_radius=23,
            font=ctk.CTkFont(family="Inter", size=14, weight="bold"),
            command=lambda: self._open_import("upload"),
        ).pack(side="left", padx=8)

        ctk.CTkButton(
            action_bar,
            text="📋 Paste Text",
            fg_color=T.BG_CARD,
            hover_color=T.BG_OPTION,
            border_width=1,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            height=46,
            width=170,
            corner_radius=23,
            font=ctk.CTkFont(family="Inter", size=14, weight="bold"),
            command=lambda: self._open_import("paste"),
        ).pack(side="left", padx=8)

        # 4. Settings Section (PDF Engine)
        settings_frame = ctk.CTkFrame(scroll, fg_color=T.BG_CARD, corner_radius=T.CORNER_RADIUS, border_width=1, border_color=T.BORDER)
        settings_frame.pack(fill="x", pady=(12, 12), padx=4)

        s_inner = ctk.CTkFrame(settings_frame, fg_color="transparent")
        s_inner.pack(padx=20, pady=16, fill="x")
        s_inner.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            s_inner,
            text="PDF Engine Settings:",
            font=T.FONT_BODY,
            text_color=T.TEXT_PRIMARY,
        ).grid(row=0, column=0, padx=(0, 12), sticky="w")

        engine_var = ctk.StringVar()

        def on_engine_change(choice):
            engine_map = {
                "PyMuPDF4LLM (LLM Optimized)": "pymupdfllm",
                "Vision OCR (Scanned PDFs)": "vision"
            }
            self.controller.set_pdf_engine(engine_map.get(choice, "pymupdfllm"))

        reverse_map = {
            "pymupdfllm": "PyMuPDF4LLM (LLM Optimized)",
            "pymupdf4llm": "PyMuPDF4LLM (LLM Optimized)",
            "vision": "Vision OCR (Scanned PDFs)"
        }
        engine_var.set(reverse_map.get(self.controller.pdf_engine, "PyMuPDF4LLM (LLM Optimized)"))

        ctk.CTkOptionMenu(
            s_inner,
            values=["PyMuPDF4LLM (LLM Optimized)", "Vision OCR (Scanned PDFs)"],
            variable=engine_var,
            command=on_engine_change,
            fg_color=T.BG_OPTION,
            button_color=T.ACCENT_BLUE,
            button_hover_color=T.ACCENT_PURPLE,
            dropdown_fg_color=T.BG_CARD,
        ).grid(row=0, column=1, sticky="w")

    def _open_import(self, mode: str) -> None:
        top = self.winfo_toplevel()
        if hasattr(top, "open_import_dialog"):
            top.open_import_dialog(self.controller, self._on_import_complete, initial_mode=mode)
        else:
            ImportDialog(top, self.controller, self._on_import_complete, initial_mode=mode)

    def _on_import_complete(self, record: dict) -> None:
        if not self.winfo_exists():
            return
        self.on_quiz()
