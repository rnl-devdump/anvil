# src/ui/quiz_view.py
import random
import threading
import customtkinter as ctk
from tkinter import messagebox

from src.ui import theme as T
from src.ui.import_dialog import ImportDialog
from src.ui.widgets import AnvilLogo, GradientButton


class QuizView(ctk.CTkFrame):

    LETTERS = ("A", "B", "C", "D")


    def __init__(self, master, controller, on_back, **kwargs):

        super().__init__(master, fg_color=T.BG_DEEP, **kwargs)

        self.controller = controller

        self.on_back = on_back


        self.questions: list[dict] = []

        self.current_index = 0

        self.selected_choice: str | None = None

        self._evaluating = False

        self.question_scores: dict[int, float] = {}


        self.grid_columnconfigure(1, weight=1)

        self.grid_rowconfigure(1, weight=1)


        self._build_header()
        self._build_sidebar()
        self._build_quiz_panel()


    def _build_header(self) -> None:

        header = ctk.CTkFrame(self, fg_color="transparent")

        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=24, pady=(20, 8))

        header.grid_columnconfigure(1, weight=1)


        AnvilLogo(header).grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            header,
            text="Quiz",
            font=T.FONT_HEADING,
            text_color=T.TEXT_PRIMARY,
        ).grid(row=0, column=1)

        actions_frame = ctk.CTkFrame(header, fg_color="transparent")
        actions_frame.grid(row=0, column=2, sticky="e")

        ctk.CTkButton(
            actions_frame,
            text="📄 Export PDF",
            width=100,
            fg_color=T.BG_OPTION,
            hover_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            command=self._export_pdf,
        ).pack(side="left", padx=(0, 8))

        ctk.CTkButton(
            actions_frame,
            text="← Home",
            width=80,
            fg_color="transparent",
            hover_color=T.BG_CARD,
            text_color=T.TEXT_SECONDARY,
            command=self.on_back,
        ).pack(side="left")


    def _build_sidebar(self) -> None:

        sidebar = ctk.CTkFrame(
            self,
            fg_color=T.BG_SIDEBAR,
            corner_radius=T.CORNER_RADIUS_SM,
            width=240,
        )

        sidebar.grid(row=1, column=0, sticky="nsew", padx=(24, 8), pady=(0, 24))

        sidebar.grid_propagate(False)

        sidebar.grid_rowconfigure(1, weight=1)

        sidebar.grid_columnconfigure(0, weight=1)


        ctk.CTkLabel(
            sidebar,
            text="Quiz History",
            font=T.FONT_BODY,
            text_color=T.TEXT_SECONDARY,
        ).grid(row=0, column=0, padx=16, pady=(16, 8), sticky="w")


        self.history_list = ctk.CTkScrollableFrame(
            sidebar,
            fg_color="transparent",
            scrollbar_button_color=T.BG_CARD,
        )

        self.history_list.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)

        self.history_list.grid_columnconfigure(0, weight=1)


        btn_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        btn_frame.grid(row=2, column=0, padx=16, pady=16, sticky="ew")
        btn_frame.grid_columnconfigure((0, 1), weight=1)

        GradientButton(
            btn_frame,
            text="Import",
            command=self._open_import,
        ).grid(row=0, column=0, padx=(0, 4), sticky="ew")

        ctk.CTkButton(
            btn_frame,
            text="Export PDF",
            fg_color=T.BG_OPTION,
            hover_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            command=self._export_pdf,
        ).grid(row=0, column=1, padx=(4, 0), sticky="ew")


        self.refresh_history()


    def _build_quiz_panel(self) -> None:

        panel = ctk.CTkFrame(
            self,
            fg_color=T.BG_CARD,
            corner_radius=T.CORNER_RADIUS,
            border_width=1,
            border_color=T.BORDER,
        )

        panel.grid(row=1, column=1, sticky="nsew", padx=(8, 24), pady=(0, 24))

        panel.grid_columnconfigure(0, weight=1)

        panel.grid_rowconfigure(3, weight=1)


        top = ctk.CTkFrame(panel, fg_color="transparent")

        top.grid(row=0, column=0, sticky="ew", padx=28, pady=(24, 8))

        top.grid_columnconfigure(0, weight=1)


        self.q_label = ctk.CTkLabel(
            top,
            text="Question 0 of 0",
            font=T.FONT_SMALL,
            text_color=T.TEXT_SECONDARY,
        )
        self.q_label.grid(row=0, column=0, sticky="w")


        self.pct_label = ctk.CTkLabel(
            top,
            text="0% done",
            font=T.FONT_SMALL,
            text_color=T.ACCENT_PURPLE,
        )
        self.pct_label.grid(row=0, column=1, sticky="e")


        self.progress = ctk.CTkProgressBar(
            panel,
            progress_color=T.ACCENT_BLUE,
            fg_color=T.BG_OPTION,
            height=6,
            corner_radius=3,
        )

        self.progress.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 16))

        self.progress.set(0)


        self.question_frame = ctk.CTkFrame(panel, fg_color="transparent")
        self.question_frame.grid(row=2, column=0, sticky="ew", padx=28, pady=(0, 12))
        self.question_frame.grid_columnconfigure(1, weight=1)


        self.num_badge = ctk.CTkLabel(
            self.question_frame,
            text="1",
            width=36,
            height=36,
            fg_color=T.ACCENT_BLUE,
            corner_radius=8,
            font=T.FONT_BODY,
            text_color=T.TEXT_PRIMARY,
        )
        self.num_badge.grid(row=0, column=0, padx=(0, 16), sticky="nw")


        self.question_text = ctk.CTkLabel(
            self.question_frame,
            text="Import materials to generate your first quiz.",
            font=T.FONT_QUESTION,
            text_color=T.TEXT_PRIMARY,
            wraplength=520,
            justify="left",
            anchor="w",
        )
        self.question_text.grid(row=0, column=1, sticky="ew")


        self.answer_frame = ctk.CTkScrollableFrame(
            panel,
            fg_color="transparent",
            height=280,
        )
        self.answer_frame.grid(row=3, column=0, sticky="nsew", padx=28, pady=(0, 12))
        self.answer_frame.grid_columnconfigure(0, weight=1)


        self.feedback_box = ctk.CTkFrame(
            panel,
            fg_color=T.BG_OPTION,
            corner_radius=T.CORNER_RADIUS_SM,
            border_width=1,
            border_color=T.BORDER,
        )
        self.feedback_box.grid_columnconfigure(0, weight=1)


        nav = ctk.CTkFrame(panel, fg_color="transparent")
        nav.grid(row=5, column=0, sticky="ew", padx=28, pady=(0, 24))

        nav.grid_columnconfigure(0, weight=1)


        self.submit_btn = GradientButton(
            nav,
            text="Submit",
            width=120,
            command=self._submit,
        )
        self.submit_btn.grid(row=0, column=1, padx=(0, 8))


        ctk.CTkButton(
            nav,
            text="Next →",
            width=100,
            fg_color=T.BG_OPTION,
            hover_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            command=self._next_question,
        ).grid(row=0, column=2)


    def refresh_history(self) -> None:
        if not self.history_list.winfo_exists():
            return

        for w in self.history_list.winfo_children():
            w.destroy()


        records = self.controller.quiz_store.all

        if not records:

            ctk.CTkLabel(
                self.history_list,
                text="No quizzes yet",
                font=T.FONT_SMALL,
                text_color=T.TEXT_MUTED,
            ).grid(row=0, column=0, pady=12, padx=8, sticky="w")
            return


        for i, record in enumerate(records):

            btn = ctk.CTkButton(
                self.history_list,
                text=f"{record['title']}\n{record['question_count']} questions",
                font=T.FONT_SMALL,

                fg_color=T.BG_OPTION if record["id"] != self.controller.active_quiz_id else T.ACCENT_BLUE,
                hover_color=T.BG_CARD,
                text_color=T.TEXT_PRIMARY,
                anchor="w",
                height=56,

                command=lambda rid=record["id"]: self.load_quiz(rid),
            )

            btn.grid(row=i, column=0, sticky="ew", pady=4, padx=4)


    def _open_import(self) -> None:
        top = self.winfo_toplevel()
        if hasattr(top, "open_import_dialog"):
            top.open_import_dialog(self.controller, self._on_import_complete)
        else:
            ImportDialog(top, self.controller, self._on_import_complete)

    def _export_pdf(self) -> None:
        if not self.questions:
            messagebox.showwarning("No Quiz", "There is no active quiz loaded to export.")
            return

        from customtkinter import filedialog

        title_suggestion = "quiz"
        if self.controller.active_quiz_id:
            rec = self.controller.quiz_store.get(self.controller.active_quiz_id)
            if rec and rec.get("title"):
                title_suggestion = rec["title"].split("(")[0].strip()
        elif self.controller.file:
            title_suggestion = self.controller.file.display_name

        safe_filename = "".join(c for c in title_suggestion if c.isalnum() or c in (" ", "_", "-")).strip()
        if not safe_filename:
            safe_filename = "quiz"
        default_name = f"{safe_filename}.pdf"

        filepath = filedialog.asksaveasfilename(
            title="Export Quiz to PDF",
            defaultextension=".pdf",
            initialfile=default_name,
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
        )

        if not filepath:
            return

        try:
            out_path = self.controller.export_active_quiz_to_pdf(filepath)
            messagebox.showinfo("Export Successful", f"Quiz exported successfully to:\n{out_path}")
        except Exception as e:
            messagebox.showerror("Export Failed", f"Failed to export quiz to PDF:\n{e}")




    def _on_import_complete(self, record: dict) -> None:
        if not self.winfo_exists():
            return
        
        self.refresh_history()

        self.load_quiz(record["id"])


    def load_quiz(self, quiz_id: str) -> None:
        try:

            self.questions = self.controller.load_quiz_from_history(quiz_id)
        except ValueError as e:

            messagebox.showerror("Error", str(e))
            return

        self.current_index = 0

        self.question_scores = {}

        self.refresh_history()

        self._render_question()


    def _clear_feedback_box(self) -> None:
        for w in self.feedback_box.winfo_children():
            w.destroy()
        self.feedback_box.grid_forget()

    def _show_feedback_box(
        self,
        status_text: str,
        score: float | int | None = None,
        feedback_text: str = "",
        expected_answer: str = "",
        color: str = T.TEXT_SECONDARY,
    ) -> None:
        self._clear_feedback_box()
        self.feedback_box.configure(border_color=color)

        if score is not None:
            sc_val = round(score / 10, 1) if score > 10 else score
            sc_str = f"{int(sc_val)}" if float(sc_val).is_integer() else f"{sc_val:.1f}"
            header_str = f"{status_text}  ·  Score {sc_str}/10"
        else:
            header_str = status_text

        # Status & Score header (Centered)
        ctk.CTkLabel(
            self.feedback_box,
            text=header_str,
            font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
            text_color=color,
            justify="center",
            anchor="center",
        ).pack(pady=(12, 4 if (feedback_text or expected_answer) else 12), padx=16, fill="x")

        # Feedback text (Centered)
        if feedback_text:
            ctk.CTkLabel(
                self.feedback_box,
                text=feedback_text,
                font=T.FONT_BODY,
                text_color=T.TEXT_PRIMARY,
                wraplength=580,
                justify="center",
                anchor="center",
            ).pack(pady=(0, 6 if expected_answer else 12), padx=16, fill="x")

        # Expected Answer below score & feedback (Centered)
        if expected_answer:
            clean_exp = self._strip_md(expected_answer)
            ctk.CTkLabel(
                self.feedback_box,
                text=f"Expected Answer: {clean_exp}",
                font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                text_color=T.ACCENT_PURPLE if color != T.ERROR else T.TEXT_SECONDARY,
                wraplength=580,
                justify="center",
                anchor="center",
            ).pack(pady=(2, 12), padx=16, fill="x")

        self.feedback_box.grid(row=4, column=0, sticky="ew", padx=28, pady=(0, 12))

    def _render_question(self) -> None:

        for w in self.answer_frame.winfo_children():
            w.destroy()

        self._clear_feedback_box()

        self.selected_choice = None


        total = len(self.questions)

        if total == 0:

            self.q_label.configure(text="Question 0 of 0")
            self.pct_label.configure(text="0% done")
            self.progress.set(0)
            return


        idx = self.current_index
        q = self.questions[idx]
        qtype = q["type"]


        self.q_label.configure(text=f"Question {idx + 1} of {total}")
        pct = int(((idx) / total) * 100)
        self.pct_label.configure(text=f"{pct}% done")
        self.progress.set(idx / total)


        self.num_badge.configure(text=str(idx + 1))
        self.question_text.configure(text=q["question"])


        if qtype == "MULTIPLE_CHOICE":
            self._render_mc(q)
        elif qtype == "IDENTIFICATION":
            self._render_identification()
        elif qtype == "ENUMERATION":
            self._render_enumeration()
        elif qtype == "PARAGRAPH":
            self._render_paragraph()
        elif qtype == "TRUE_FALSE":
            self._render_tf(q)
        elif qtype == "MATCHING":
            self._render_matching(q)
        else:
            ctk.CTkLabel(
                self.answer_frame,
                text=f"Unsupported type: {qtype}",
                text_color=T.ERROR,
            ).grid(row=0, column=0, sticky="w")


    def _render_mc(self, q: dict) -> None:

        for i, choice in enumerate(q["choices"]):

            letter = self.LETTERS[i]

            row = ctk.CTkFrame(self.answer_frame, fg_color="transparent")
            row.grid(row=i, column=0, sticky="ew", pady=6)
            row.grid_columnconfigure(1, weight=1)


            badge = ctk.CTkLabel(
                row,
                text=letter,
                width=32,
                height=32,
                fg_color=T.BG_DEEP,
                corner_radius=8,
                text_color=T.ACCENT_PURPLE,
                font=T.FONT_BODY,
            )
            badge.grid(row=0, column=0, padx=(0, 12))


            btn = ctk.CTkButton(
                row,
                text=choice,
                anchor="w",
                fg_color=T.BG_OPTION,
                hover_color=T.BORDER,
                text_color=T.TEXT_SECONDARY,
                font=T.FONT_BODY,
                height=48,

                command=lambda c=choice, b=None: self._select_mc(c),
            )
            btn.grid(row=0, column=1, sticky="ew")

            btn.configure(command=lambda c=choice, b=btn: self._select_mc(c, b))

            btn._choice = choice


    def _select_mc(self, choice: str, btn=None) -> None:

        self.selected_choice = choice

        for w in self.answer_frame.winfo_children():
            if isinstance(w, ctk.CTkFrame):
                for child in w.winfo_children():

                    if isinstance(child, ctk.CTkButton) and hasattr(child, "_choice"):

                        child.configure(
                            fg_color=T.ACCENT_BLUE if child._choice == choice else T.BG_OPTION
                        )


    def _render_identification(self) -> None:

        self.answer_entry = ctk.CTkEntry(
            self.answer_frame,
            placeholder_text="Type your answer…",
            fg_color=T.BG_OPTION,
            border_color=T.BORDER,
            text_color=T.TEXT_PRIMARY,
            font=T.FONT_BODY,
            height=44,
        )
        self.answer_entry.grid(row=0, column=0, sticky="ew", pady=8)
        self.answer_entry.bind("<Return>", lambda e: self._submit())


    def _render_enumeration(self) -> None:

        ctk.CTkLabel(
            self.answer_frame,
            text="Enter items separated by commas or new lines:",
            font=T.FONT_SMALL,
            text_color=T.TEXT_MUTED,
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))


        self.answer_text = ctk.CTkTextbox(
            self.answer_frame,
            fg_color=T.BG_OPTION,
            text_color=T.TEXT_PRIMARY,
            font=T.FONT_BODY,
            height=120,
        )
        self.answer_text.grid(row=1, column=0, sticky="ew")
        self.answer_text.bind("<Return>", self._on_textbox_enter)
        self.answer_text.bind("<Shift-Return>", lambda e: None)


    def _render_paragraph(self) -> None:
        ctk.CTkLabel(
            self.answer_frame,
            text="Write your answer in a short paragraph:",
            font=T.FONT_SMALL,
            text_color=T.TEXT_MUTED,
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))

        self.answer_text = ctk.CTkTextbox(
            self.answer_frame,
            fg_color=T.BG_OPTION,
            text_color=T.TEXT_PRIMARY,
            font=T.FONT_BODY,
            height=160,
        )
        self.answer_text.grid(row=1, column=0, sticky="ew")
        self.answer_text.bind("<Return>", self._on_textbox_enter)
        self.answer_text.bind("<Shift-Return>", lambda e: None)

    def _render_tf(self, q: dict) -> None:
        choices = ["True", "False"]
        for i, choice in enumerate(choices):
            row = ctk.CTkFrame(self.answer_frame, fg_color="transparent")
            row.grid(row=i, column=0, sticky="ew", pady=6)
            row.grid_columnconfigure(1, weight=1)

            btn = ctk.CTkButton(
                row,
                text=choice,
                anchor="w",
                fg_color=T.BG_OPTION,
                hover_color=T.BORDER,
                text_color=T.TEXT_SECONDARY,
                font=T.FONT_BODY,
                height=48,
                command=lambda c=choice, b=None: self._select_mc(c),
            )
            btn.grid(row=0, column=1, sticky="ew")
            btn.configure(command=lambda c=choice, b=btn: self._select_mc(c, b))
            btn._choice = choice

    def _render_matching(self, q: dict) -> None:
        self.matching_vars = {}
        pairs = q["pairs"]
        responses = [p["response"] for p in pairs]
        
        shuffled = list(responses)
        random.shuffle(shuffled)
        options = ["Select..."] + shuffled
        
        for i, pair in enumerate(pairs):
            premise = pair["premise"]
            
            row = ctk.CTkFrame(self.answer_frame, fg_color="transparent")
            row.grid(row=i, column=0, sticky="ew", pady=6)
            row.grid_columnconfigure(1, weight=1)

            lbl = ctk.CTkLabel(
                row,
                text=premise,
                font=T.FONT_BODY,
                text_color=T.TEXT_PRIMARY,
                wraplength=360,
                justify="left",
                anchor="w",
            )
            lbl.grid(row=0, column=0, padx=(0, 16), sticky="w")

            var = ctk.StringVar(value="Select...")
            dropdown = ctk.CTkOptionMenu(
                row,
                values=options,
                variable=var,
                fg_color=T.BG_OPTION,
                button_color=T.BG_CARD,
                button_hover_color=T.BORDER,
                text_color=T.TEXT_SECONDARY,
                dropdown_fg_color=T.BG_CARD,
                dropdown_text_color=T.TEXT_PRIMARY,
            )
            dropdown.grid(row=0, column=1, sticky="e")
            self.matching_vars[premise] = var


    def _on_textbox_enter(self, event):
        """ENTER submits the answer; SHIFT+ENTER inserts a newline."""
        self._submit()
        return "break"

    def _get_user_answer(self) -> any:
        q = self.questions[self.current_index]
        qtype = q["type"]

        if qtype == "MULTIPLE_CHOICE":
            return self.selected_choice or ""
        
        if qtype == "TRUE_FALSE":
            if not self.selected_choice:
                return None
            return self.selected_choice == "True"
            
        if qtype == "MATCHING":
            ans = {premise: var.get() for premise, var in self.matching_vars.items()}
            if any(val == "Select..." for val in ans.values()):
                return None
            return ans

        if qtype == "IDENTIFICATION":
            return self.answer_entry.get().strip()

        if qtype in ("ENUMERATION", "PARAGRAPH"):
            return self.answer_text.get("1.0", "end").strip()

        return ""


    @staticmethod
    def _strip_md(text: any) -> str:
        if not isinstance(text, str):
            return str(text) if text is not None else ""
        import re
        s = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
        s = re.sub(r"\*([^*]+)\*", r"\1", s)
        s = re.sub(r"__([^_]+)__", r"\1", s)
        s = re.sub(r"_([^_]+)_", r"\1", s)
        s = re.sub(r"[\*\_\`\~]", "", s)
        return s.strip()

    @staticmethod
    def _normalize_answer(text: any) -> str:
        import re
        if text is None:
            return ""
        s = str(text).strip().lower()
        # Remove option prefixes like "a) ", "A. ", "1. ", "1) "
        s = re.sub(r"^[a-d1-4][\.\)]\s*", "", s)
        # Remove leading articles ("a ", "an ", "the ")
        s = re.sub(r"^(a|an|the)\s+", "", s)
        # Remove markdown bold/italics
        s = re.sub(r"[\*\_\`\~]", "", s)
        # Remove trailing punctuation (periods, commas, colons, semicolons, quotes, question marks)
        s = re.sub(r"[\.,;:!?\"']+$", "", s)
        return s.strip()

    def _evaluate_identification(self, user_norm: str, expected_norm: str) -> bool:
        if not user_norm or not expected_norm:
            return False
        if user_norm == expected_norm:
            return True
        # Substring matching for terms
        if len(user_norm) >= 3 and len(expected_norm) >= 3:
            if user_norm in expected_norm or expected_norm in user_norm:
                return True

        # Token set match / content word overlap (ignore common stop words)
        stop_words = {"is", "are", "a", "an", "the", "in", "on", "of", "to", "for", "with", "or", "and", "that", "given", "used", "by"}
        user_tokens = {w for w in user_norm.split() if w not in stop_words}
        expected_tokens = {w for w in expected_norm.split() if w not in stop_words}

        if user_tokens and expected_tokens:
            if user_tokens == expected_tokens:
                return True
            intersection = user_tokens.intersection(expected_tokens)
            overlap_ratio_expected = len(intersection) / len(expected_tokens)
            overlap_ratio_user = len(intersection) / len(user_tokens)
            # Accept if significant content words overlap (>= 45% of expected or >= 50% of user answer)
            if overlap_ratio_expected >= 0.45 or (len(intersection) >= 3 and overlap_ratio_user >= 0.5):
                return True

        return False

    def _submit(self) -> None:
        if not self.questions or self._evaluating:
            return

        q = self.questions[self.current_index]
        qtype = q["type"]
        user = self._get_user_answer()

        if user is None or (isinstance(user, str) and not user):
            messagebox.showwarning("Answer required", "Please provide a complete answer first.")
            return

        if qtype == "PARAGRAPH":
            self._submit_paragraph(q, user)
            return

        if qtype == "MULTIPLE_CHOICE":
            user_norm = self._normalize_answer(user)
            expected_norm = self._normalize_answer(q["answer"])
            correct = (user == q["answer"]) or (user_norm == expected_norm) or (user_norm in expected_norm) or (expected_norm in user_norm)
            self._show_result(correct, q["answer"])

        elif qtype == "TRUE_FALSE":
            user_bool = str(user).lower() in ("true", "t", "1", "yes")
            expected_bool = str(q["answer"]).lower() in ("true", "t", "1", "yes")
            correct = user_bool == expected_bool
            self._show_result(correct, str(q["answer"]))

        elif qtype == "MATCHING":
            expected = {p["premise"]: p["response"] for p in q["pairs"]}
            correct_count = 0
            for p, r in user.items():
                exp_r = expected.get(p, "")
                if r == exp_r or self._normalize_answer(r) == self._normalize_answer(exp_r):
                    correct_count += 1
            total = len(expected)
            correct = correct_count == total
            self._show_result(
                correct,
                "All pairs matched correctly",
                extra=f"Matched {correct_count}/{total} pairs.",
            )

        elif qtype == "IDENTIFICATION":
            user_norm = self._normalize_answer(user)
            expected_norm = self._normalize_answer(q["answer"])
            fast_correct = self._evaluate_identification(user_norm, expected_norm)
            if fast_correct:
                self._show_result(True, q["answer"])
            elif len(str(user).strip().split()) >= 3 or len(expected_norm.split()) >= 3:
                # User provided a multi-word or sentence answer - evaluate conceptually using AI
                self._submit_paragraph(q, user)
            else:
                self._show_result(False, q["answer"])

        elif qtype == "ENUMERATION":
            expected = q["answer"]
            if isinstance(expected, str):
                expected = [e.strip() for e in expected.split(",") if e.strip()]
            expected_norm = [self._normalize_answer(e) for e in expected if e]

            given = [self._normalize_answer(p) for p in user.replace("\n", ",").split(",") if p.strip()]
            matches = sum(1 for g in given if any(self._evaluate_identification(g, e) for e in expected_norm))
            correct = matches >= max(1, len(expected_norm) * 0.5)
            display_expected = ", ".join(expected) if isinstance(expected, list) else str(expected)
            self._show_result(
                correct,
                display_expected,
                extra=f"Matched {matches}/{len(expected_norm)} expected items.",
            )


    def _submit_paragraph(self, q: dict, user: str) -> None:
        user_norm = self._normalize_answer(user)
        expected_norm = self._normalize_answer(q.get("answer", ""))

        import difflib
        similarity = difflib.SequenceMatcher(None, user_norm, expected_norm).ratio()

        stop_words = {"is", "are", "a", "an", "the", "in", "on", "of", "to", "for", "with", "or", "and", "that", "given", "used", "by", "such", "as"}
        user_tokens = {w for w in user_norm.split() if w not in stop_words}
        expected_tokens = {w for w in expected_norm.split() if w not in stop_words}

        token_overlap = 0.0
        if user_tokens and expected_tokens:
            token_overlap = len(user_tokens.intersection(expected_tokens)) / max(len(expected_tokens), len(user_tokens))

        # Direct exact or high-similarity match -> Award 10/10 immediately!
        if user_norm == expected_norm or similarity >= 0.78 or token_overlap >= 0.75:
            self.question_scores[self.current_index] = 10.0
            self._show_feedback_box(
                status_text="✓ Correct",
                score=10,
                feedback_text="Spot-on! Your answer matches the expected reference answer.",
                expected_answer=q.get("answer", ""),
                color=T.SUCCESS,
            )
            self._check_and_update_quiz_completion()
            return

        self._evaluating = True

        self.submit_btn.configure(state="disabled")

        self._show_feedback_box("Evaluating your answer…", color=T.TEXT_SECONDARY)


        def work():

            return self.controller.evaluate_paragraph(q["question"], q["answer"], user)


        def done(result):

            self._evaluating = False

            self.submit_btn.configure(state="normal")

            final_score = float(result.score)
            if final_score > 10:
                final_score = round(final_score / 10, 1)

            qtype = q.get("type", "")
            q_text = str(q.get("question", "")).strip().lower()
            ans_text = str(q.get("answer", "")).strip()

            is_term_query = any(w in q_text for w in [
                "what is the term", "what term", "which term", "name the", "identify the", "what do you call", "what is called"
            ])
            is_binary_verdict_question = qtype != "PARAGRAPH" or is_term_query or len(ans_text.split()) <= 4

            if is_binary_verdict_question:
                # Strictly binary: Correct or Incorrect (no partial scores)
                if result.is_correct or final_score >= 7.0:
                    status = "✓ Correct"
                    color = T.SUCCESS
                    final_score = 10.0
                else:
                    status = "✗ Incorrect"
                    color = T.ERROR
                    final_score = 0.0
            else:
                # Open-ended paragraph / essay explanations:
                if final_score >= 8.0:
                    status = "✓ Correct"
                    color = T.SUCCESS
                elif final_score >= 4.0:
                    status = "Needs Work / Partial"
                    color = T.WARNING
                else:
                    status = "✗ Incorrect"
                    color = T.ERROR

            self.question_scores[self.current_index] = final_score

            self._show_feedback_box(
                status_text=status,
                score=final_score,
                feedback_text=result.feedback,
                expected_answer=q.get("answer", ""),
                color=color,
            )
            self._check_and_update_quiz_completion()


        def fail(exc):

            self._evaluating = False

            self.submit_btn.configure(state="normal")

            self._show_feedback_box(
                status_text="Evaluation Error",
                feedback_text=str(exc),
                color=T.ERROR,
            )


        def runner():
            try:

                r = work()

                self.after(0, done, r)
            except Exception as e:

                self.after(0, fail, e)


        threading.Thread(target=runner, daemon=True).start()


    def _calculate_overall_score(self) -> float:
        if not self.questions:
            return 0.0
        total_q = len(self.questions)
        answered_scores = list(self.question_scores.values())
        if not answered_scores:
            return 0.0
        avg_score = sum(answered_scores) / total_q
        return round(avg_score, 1)

    def _check_and_update_quiz_completion(self) -> None:
        if self.controller.active_quiz_id and self.questions:
            overall = self._calculate_overall_score()
            self.controller.update_quiz_score(self.controller.active_quiz_id, overall)
            self.refresh_history()

    def _show_result(self, correct: bool, expected: str, extra: str = "") -> None:
        status_text = "✓ Correct!" if correct else "✗ Incorrect"
        color = T.SUCCESS if correct else T.ERROR
        score_val = 10 if correct else 0
        self.question_scores[self.current_index] = float(score_val)

        self._show_feedback_box(
            status_text=status_text,
            score=score_val,
            feedback_text=extra,
            expected_answer=expected,
            color=color,
        )
        self._check_and_update_quiz_completion()


    def _next_question(self) -> None:

        if not self.questions:
            return

        if self.current_index < len(self.questions) - 1:

            self.current_index += 1

            self._render_question()

        else:

            self.pct_label.configure(text="100% done")
            self.progress.set(1.0)
            overall = self._calculate_overall_score()
            pct = int((overall / 10.0) * 100)

            self._show_feedback_box(
                status_text="🏆 Quiz Complete!",
                score=overall,
                feedback_text=f"Overall Final Score: {overall} / 10 ({pct}%)\nAnswered {len(self.question_scores)} of {len(self.questions)} questions.",
                color=T.ACCENT_PURPLE,
            )
