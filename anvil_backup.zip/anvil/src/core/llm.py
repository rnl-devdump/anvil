# src/core/llm.py
import threading
import json
from typing import Type, TypeVar
from openai import OpenAI

from src.core.config import LLM_MODEL
from src.core.schema import ChunkQuizResponse, ParagraphEvaluation, RagAnswer
from src.model import ensure_model_setup


T = TypeVar("T")


EXAMPLES = {

    "ChunkQuizResponse": {
        "questions": [
            {
                "type": "MULTIPLE_CHOICE",
                "question": "What is the powerhouse of the cell?",
                "choices": ["Mitochondria", "Nucleus", "Ribosome", "Vacuole"],
                "answer": "Mitochondria"
            },
            {
                "type": "IDENTIFICATION",
                "question": "The ___ is known as the powerhouse of the cell.",
                "answer": "mitochondria"
            },
            {
                "type": "TRUE_FALSE",
                "question": "The mitochondria is the powerhouse of the cell.",
                "answer": True
            },
            {
                "type": "MATCHING",
                "question": "Match the following organelles to their functions:",
                "pairs": [
                    {"premise": "Mitochondria", "response": "Powerhouse"},
                    {"premise": "Nucleus", "response": "Stores DNA"},
                    {"premise": "Ribosome", "response": "Protein synthesis"}
                ]
            }
        ]
    },

    "RagAnswer": {
        "answer": "The mitochondria is the powerhouse of the cell and generates ATP.",
        "sources": ["Page 1: Cell Biology Introduction"]
    },

    "ParagraphEvaluation": {
        "is_correct": True,
        "is_relevant": True,
        "feedback": "Great explanation of cell respiration stages.",
        "score": 9
    }
}


QUIZ_FLAT_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["MULTIPLE_CHOICE", "IDENTIFICATION", "TRUE_FALSE", "ENUMERATION", "PARAGRAPH", "MATCHING", "PROGRAM_SOLVING"]
                    },
                    "question": {"type": "string"},
                    "choices": {"type": "array", "items": {"type": "string"}},
                    "answer": {"type": ["string", "boolean", "array"]},
                    "output": {"type": "string"},
                    "pairs": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "premise": {"type": "string"},
                                "response": {"type": "string"}
                            },
                            "required": ["premise", "response"]
                        }
                    }
                },
                "required": ["type", "question", "answer"]
            }
        }
    },
    "required": ["questions"]
}


class LlmService:

    def __init__(self, model: str = LLM_MODEL):

        self.model = model

        self._openai_client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama",
        )

        threading.Thread(target=ensure_model_setup, daemon=True).start()


    @staticmethod
    def _repair_quiz_json(raw_json: str) -> str:
        """Attempt to sanitize and inject missing fields into quiz question objects."""
        import re
        try:
            data = json.loads(raw_json)
        except (json.JSONDecodeError, TypeError):
            return raw_json

        if "questions" not in data or not isinstance(data["questions"], list):
            return raw_json

        def strip_md(val):
            if isinstance(val, str):
                v = re.sub(r"\*\*([^*]+)\*\*", r"\1", val)
                v = re.sub(r"\*([^*]+)\*", r"\1", v)
                v = re.sub(r"__([^_]+)__", r"\1", v)
                v = re.sub(r"_([^_]+)_", r"\1", v)
                return v.strip()
            if isinstance(val, list):
                return [strip_md(x) for x in val]
            return val

        for q in data["questions"]:
            if not isinstance(q, dict):
                continue

            # Strip markdown formatting asterisks and underscores
            if "question" in q:
                q["question"] = strip_md(q["question"])
            if "answer" in q:
                q["answer"] = strip_md(q["answer"])
            if "choices" in q and isinstance(q["choices"], list):
                q["choices"] = strip_md(q["choices"])

            # 1. Infer missing type
            if "type" not in q:
                if "choices" in q and isinstance(q.get("choices"), list):
                    q["type"] = "MULTIPLE_CHOICE"
                elif "pairs" in q and isinstance(q.get("pairs"), list):
                    q["type"] = "MATCHING"
                elif isinstance(q.get("answer"), bool):
                    q["type"] = "TRUE_FALSE"
                elif isinstance(q.get("answer"), list):
                    q["type"] = "ENUMERATION"
                elif "__" in q.get("question", "") or "___" in q.get("question", ""):
                    q["type"] = "IDENTIFICATION"
                else:
                    q["type"] = "IDENTIFICATION"

            qtype = q.get("type", "")

            # 2. Sanitize hallucinated $defs references in answers
            ans_str = str(q.get("answer", ""))
            if "#$defs" in ans_str or "ELEMENTARY" in ans_str:
                # Replace hallucinated schema ref with sensible default
                if qtype == "TRUE_FALSE":
                    q["answer"] = True
                elif qtype == "ENUMERATION":
                    q["answer"] = ["Key concept 1", "Key concept 2"]
                else:
                    q["answer"] = q.get("question", "Correct answer")

            # 3. Clean up MULTIPLE_CHOICE answers & choices
            if qtype == "MULTIPLE_CHOICE":
                choices = q.get("choices") or []
                is_placeholder = any("option " in str(c).lower() or str(c).strip().upper() in ("A", "B", "C", "D", "CHOICE A", "CHOICE B") for c in choices) if isinstance(choices, list) else True
                
                if not choices or not isinstance(choices, list) or len(choices) < 2 or is_placeholder:
                    # Convert to IDENTIFICATION question rather than displaying dummy 'Option A/B/C/D' choices
                    q["type"] = "IDENTIFICATION"
                    qtype = "IDENTIFICATION"
                    if "choices" in q:
                        del q["choices"]
                    ans_val = str(q.get("answer", "")).strip()
                    if not ans_val or any(p in ans_val.lower() for p in ["option ", "choice "]) or ans_val.upper() in ("A", "B", "C", "D"):
                        q["answer"] = q.get("question", "")
                else:
                    # Clean option letters like "a) ", "A. " from choice strings
                    cleaned_choices = [re.sub(r"^[a-d1-4][\.\)]\s*", "", str(c)).strip() for c in choices]

                    # Check if answer is a letter code like "A", "B", "C", "D"
                    ans_upper = str(q.get("answer", "")).strip().upper()
                    letter_map = {"A": 0, "B": 1, "C": 2, "D": 3, "OPTION A": 0, "OPTION B": 1, "OPTION C": 2, "OPTION D": 3}
                    if ans_upper in letter_map and letter_map[ans_upper] < len(cleaned_choices):
                        target_ans = cleaned_choices[letter_map[ans_upper]]
                    else:
                        clean_ans = re.sub(r"^[a-d1-4][\.\)]\s*", "", str(q.get("answer", ""))).strip()
                        target_ans = cleaned_choices[0]
                        for c in cleaned_choices:
                            if clean_ans.lower() == c.lower() or clean_ans.lower() in c.lower() or c.lower() in clean_ans.lower():
                                target_ans = c
                                break

                    # If more than 4 choices, trim to 4 while ensuring target_ans is inside the top 4
                    if len(cleaned_choices) > 4:
                        if target_ans in cleaned_choices[:4]:
                            cleaned_choices = cleaned_choices[:4]
                        else:
                            cleaned_choices = [target_ans] + cleaned_choices[:3]

                    q["choices"] = cleaned_choices
                    q["answer"] = target_ans

            # 4. Clean up TRUE_FALSE questions & answers
            elif qtype == "TRUE_FALSE":
                if isinstance(q.get("answer"), str):
                    q["answer"] = q["answer"].strip().lower() in ("true", "t", "1", "yes")
                elif not isinstance(q.get("answer"), bool):
                    q["answer"] = True

                # If question ends with ? (is an interrogative), rewrite or change type to IDENTIFICATION
                q_text = q.get("question", "").strip()
                if q_text.endswith("?") or any(q_text.lower().startswith(w) for w in ["what", "which", "why", "how", "where", "who"]):
                    q["type"] = "IDENTIFICATION"
                    q["answer"] = str(q.get("answer")) if not isinstance(q.get("answer"), bool) else "True"

            # 5. Clean up ENUMERATION answers
            elif qtype == "ENUMERATION":
                if isinstance(q.get("answer"), str):
                    q["answer"] = [item.strip() for item in q["answer"].split(",") if item.strip()]
                elif not isinstance(q.get("answer"), list):
                    q["answer"] = [str(q.get("answer", "Item 1"))]

            # 6. Ensure terminology & short-answer questions remain IDENTIFICATION
            elif qtype == "IDENTIFICATION":
                ans_text = str(q.get("answer", "")).strip()
                q["answer"] = ans_text
                q_text = str(q.get("question", "")).strip().lower()
                is_term_query = any(w in q_text for w in [
                    "what is the term", "what term", "which term", "name the", "identify the", "what do you call", "what is called"
                ])
                if not is_term_query and len(ans_text.split()) > 5:
                    q["type"] = "PARAGRAPH"

            # 6b. Fix PROGRAM_SOLVING missing output and string answers
            elif qtype == "PROGRAM_SOLVING":
                if "output" not in q or not q["output"]:
                    q["output"] = "None"
                q["answer"] = str(q.get("answer", ""))

            # 7. Repair MATCHING questions: move answer -> pairs if needed
            elif qtype == "MATCHING":
                if "pairs" not in q and isinstance(q.get("answer"), list):
                    candidate = q["answer"]
                    if candidate and all(
                        isinstance(p, dict) and "premise" in p and "response" in p
                        for p in candidate
                    ):
                        q["pairs"] = candidate
                # Pad pairs to minimum 3 if too few
                if "pairs" in q and isinstance(q["pairs"], list) and len(q["pairs"]) < 3:
                    while len(q["pairs"]) < 3:
                        idx = len(q["pairs"]) + 1
                        q["pairs"].append({"premise": f"Concept {idx}", "response": f"Description {idx}"})

        return json.dumps(data)

    def _create_completion(self, messages: list[dict], response_model: Type[T]) -> T:

        max_retries = 2

        last_exception = None


        schema_json = json.dumps(response_model.model_json_schema(), indent=2)

        model_name = response_model.__name__

        example_obj = EXAMPLES.get(model_name, {})

        example_json = json.dumps(example_obj, indent=2)


        schema_instruction = (
            f"\n\nCRITICAL: You must return a JSON object containing the actual data (do not copy the schema or definition itself), conforming strictly to this JSON Schema:\n"
            f"{schema_json}\n\n"
            f"Here is an example of a valid JSON response conforming to the schema:\n"
            f"```json\n{example_json}\n```\n"
            "Ensure you populate the JSON with actual data from the provided text/context (do not use the example values). "
            "Do not include any preambles, apologies, or conversational text. Output ONLY the raw JSON block."
        )


        base_history = []

        for msg in messages:

            base_history.append(dict(msg))


        system_msg_idx = -1

        for idx, msg in enumerate(base_history):

            if msg.get("role") == "system":

                system_msg_idx = idx

                break


        if system_msg_idx != -1:

            base_history[system_msg_idx]["content"] += schema_instruction

        else:

            base_history.insert(0, {"role": "system", "content": schema_instruction})


        # Use flat non-$defs schema for ChunkQuizResponse to prevent local Ollama $defs hallucinations
        json_schema_arg = QUIZ_FLAT_SCHEMA if model_name == "ChunkQuizResponse" else response_model.model_json_schema()

        for attempt in range(max_retries):

            raw_content = ""

            try:

                history = [dict(m) for m in base_history]

                completion = self._openai_client.chat.completions.create(
                    model=self.model,
                    messages=history,
                    temperature=0.0,
                    response_format={
                        "type": "json_schema",
                        "json_schema": {
                            "name": model_name,
                            "schema": json_schema_arg,
                            "strict": True
                        }
                    }
                )

                raw_content = completion.choices[0].message.content or ""

                if model_name == "ChunkQuizResponse":
                    raw_content = self._repair_quiz_json(raw_content)

                return response_model.model_validate_json(raw_content)

            except Exception as e:

                last_exception = e

                print(f"[Attempt {attempt+1}/{max_retries}] JSON validation failed for {response_model.__name__}: {e}")
                print(f"Raw response was:\n{raw_content}\n")


        raise RuntimeError(f"Max retries exceeded. Total attempts: {max_retries}, Last error: {last_exception}")


    def generate_questions_for_chunk(
        self,
        chunk_text: str,
        preferences: str = "",
        num_questions: int = 2
    ) -> ChunkQuizResponse:
        pref_instruction = f"\nUser preferences: {preferences}\nPlease adapt the questions to match these preferences." if preferences else ""

        return self._create_completion(
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"You are Student Study Buddy System, an expert AI educator crafting a structured academic quiz.\n"
                        f"Generate exactly {num_questions} clear, relevant, high-quality quiz questions.\n"
                        f"If the text chunk is brief or lacks detail, generate relevant academic questions based on your own knowledge about the document's subject matter.\n"
                        f"CRITICAL: You MUST ensure that the questions are distributed equally across ALL 5 TYPES: TRUE_FALSE, MATCHING, IDENTIFICATION, MULTIPLE_CHOICE, and PROGRAM_SOLVING.\n"
                        f"If generating 5 questions, you MUST provide exactly one of each type. Never miss a question type.\n"
                        f"Question type guidelines:\n"
                        f"- MULTIPLE_CHOICE: 'choices' MUST contain exactly 4 distinct, real domain choice values. NEVER output placeholder strings like 'Option A', 'Option B', 'Option C', 'Option D'. 'answer' MUST be the exact choice text from 'choices'.\n"
                        f"- TRUE_FALSE: 'question' MUST be a declarative statement ending with a period (e.g. 'DBSCAN identifies noise points.'). NEVER ask a question ending with '?'. 'answer' MUST be boolean true or false.\n"
                        f"- IDENTIFICATION: question asking for a specific term or concept. Provide the concise term as 'answer'.\n"
                        f"- MATCHING: 'pairs' contains 3 to 10 premise-response pairs. 'answer' should match the premise-response list.\n"
                        f"- PROGRAM_SOLVING: 'question' MUST contain a code snippet with missing parts or errors to be solved. 'output' MUST contain the expected output. 'answer' MUST be the correct code statement/s to fill in.\n"
                        f"{pref_instruction}"
                    ),
                },
                {"role": "user", "content": f"Text chunk:\n\n{chunk_text}"},
            ],
            response_model=ChunkQuizResponse,
        )


    def fill_and_convert_questions(
        self,
        topic: str,
        question_type: str,
        count: int,
        source_questions: list[dict] | None = None,
        existing_questions: list[str] | None = None,
        context_text: str = "",
    ) -> ChunkQuizResponse:
        """Convert existing questions to a specific type, and generate new ones to fill gaps in coverage.

        Args:
            topic: The document/subject topic for relevance.
            question_type: One of TRUE_FALSE, MATCHING, IDENTIFICATION, MULTIPLE_CHOICE.
            count: How many total questions of this type we need.
            source_questions: List of questions to convert into the requested question_type.
            existing_questions: List of existing question texts to avoid duplicating.
            context_text: Optional document text for context.
        """
        existing_list = ""
        if existing_questions:
            existing_list = "\n".join(f"- {q}" for q in existing_questions[:20])
            existing_list = f"\n\nDo NOT repeat or rephrase any of these existing questions:\n{existing_list}"

        type_guidelines = {
            "TRUE_FALSE": (
                "Generate TRUE_FALSE questions. Each question MUST be a declarative statement "
                "ending with a period (NOT a question mark). The 'answer' MUST be a boolean true or false. "
                "Example: 'The mitochondria is the powerhouse of the cell.' with answer: true"
            ),
            "MATCHING": (
                "Generate MATCHING questions. Each question MUST have a 'pairs' array with 5-10 "
                "premise-response pairs. Each pair has a 'premise' (key term) and 'response' (description). "
                "The 'answer' field should be set to the first premise text."
            ),
            "IDENTIFICATION": (
                "Generate IDENTIFICATION questions. Each asks for a specific term or concept. "
                "The 'answer' MUST be a concise term (1-5 words). "
                "Example: 'The process by which plants convert sunlight to energy.' answer: 'Photosynthesis'"
            ),
            "MULTIPLE_CHOICE": (
                "Generate MULTIPLE_CHOICE questions. Each MUST have a 'choices' array with exactly 4 "
                "distinct, real answer options. NEVER use placeholders like 'Option A'. "
                "The 'answer' MUST be the exact text of the correct choice from 'choices'."
            ),
            "PROGRAM_SOLVING": (
                "Generate PROGRAM_SOLVING questions. Each MUST present a code snippet in 'question' with missing parts or errors. "
                "'output' MUST be the expected output of the code. "
                "'answer' MUST be the correct code statement/s."
            ),
        }

        guideline = type_guidelines.get(question_type, type_guidelines["IDENTIFICATION"])

        context_section = ""
        if context_text:
            context_section = f"\n\nReference material:\n{context_text[:2000]}"

        source_section = ""
        if source_questions:
            src_text = "\n".join(f"- {q.get('question')} (Answer: {q.get('answer')})" for q in source_questions)
            source_section = (
                f"\n\nCRITICAL TASK: First, CONVERT the following questions into {question_type} format.\n"
                f"Ensure they strictly follow the {question_type} structure and retain their original educational value.\n"
                f"Original Questions:\n{src_text}\n"
            )

        return self._create_completion(
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"You are Student Study Buddy System, an expert AI educator.\n"
                        f"Generate exactly {count} quiz questions of type {question_type} about the topic: {topic}.\n"
                        f"All questions MUST be relevant to the subject matter. Use your own knowledge to create "
                        f"high-quality, academically accurate questions if the provided context is insufficient.\n"
                        f"EVERY question MUST have a non-empty 'question' field with meaningful text.\n"
                        f"{guideline}\n"
                        f"{source_section}"
                        f"{existing_list}"
                    ),
                },
                {
                    "role": "user",
                    "content": f"Topic: {topic}{context_section}\n\nGenerate {count} {question_type} questions.",
                },
            ],
            response_model=ChunkQuizResponse,
        )


    def answer_question(self, question: str, context_chunks: list[str], chat_history: list[dict] | None = None) -> RagAnswer:
        context = "\n\n---\n\n".join(context_chunks) if context_chunks else "No study document currently loaded."
        messages = [
            {
                "role": "system",
                "content": (
                    "You are Student Study Buddy System, an intelligent, friendly AI study assistant.\n"
                    "CRITICAL CONVERSATIONAL THREAD & FOLLOW-UP RULES:\n"
                    "1. CONVERSATIONAL CONTINUITY & PRONOUN RESOLUTION: You have access to the conversation history. When the user asks a follow-up question using pronouns or brief references like 'it', 'this', 'that', 'explain it', 'why?', or 'give an example', YOU MUST RESOLVE THE PRONOUN DIRECTLY AGAINST THE IMMEDIATELY PRECEDING ASSISTANT TURN IN THE CHAT HISTORY.\n"
                    "2. PRIORITIZE RECENT CONVERSATION THREAD: Do NOT jump to an unrelated topic from the document context if the user is asking to elaborate on or explain the immediately preceding discussion topic.\n"
                    "3. GREETINGS & CASUAL MESSAGES: If user input is a greeting, respond warmly.\n"
                    "4. ACCURACY & CONTEXT: Use the provided document context if relevant to the active topic, otherwise rely on your general knowledge to give clear, helpful explanations."
                ),
            }
        ]
        
        if chat_history:
            for m in chat_history:
                messages.append({"role": m["role"], "content": m["content"]})
            
        messages.append({"role": "user", "content": f"Study Material Context:\n{context}\n\nUser Question: {question}"})
        
        return self._create_completion(
            messages=messages,
            response_model=RagAnswer,
        )


    def evaluate_paragraph_answer(
        self,
        question: str,
        model_answer: str,
        user_answer: str,
    ) -> ParagraphEvaluation:

        return self._create_completion(
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Grade a student's answer to a study quiz question strictly on a 0 to 10 scale.\n"
                        "STRICT EVALUATION RUBRIC:\n"
                        "- 9 to 10 / 10 (Full Credit): Complete, accurate, and clearly answers all core concepts of the question.\n"
                        "- 5 to 8 / 10 (Partial Credit): Mostly correct but missing some supporting details or explanations.\n"
                        "- 2 to 4 / 10 (Incomplete / Fragment): Very brief, incomplete definition, or missing critical information (e.g., answering just 'Names given' when asked to define identifiers).\n"
                        "- 0 to 1 / 10 (Incorrect): Factually wrong or irrelevant answer.\n\n"
                        "CRITICAL GRADING RULES:\n"
                        "1. Do NOT assign 8-10 points to short 2-3 word fragments that lack essential required information.\n"
                        "2. Set is_correct = True ONLY if score >= 8. If score < 8, set is_correct = False.\n"
                        "3. Provide concise, clear feedback explaining what key details were present or missing."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {question}\n\n"
                        f"Reference model answer:\n{model_answer}\n\n"
                        f"Student answer:\n{user_answer}"
                    ),
                },
            ],

            response_model=ParagraphEvaluation,
        )
