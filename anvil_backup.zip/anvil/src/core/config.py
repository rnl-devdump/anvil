# src/core/config.py
import os


def resolve_llm_model() -> str:
    env_model = os.getenv("ANVIL_LLM_MODEL")
    if env_model:
        return env_model
    try:
        import ollama
        models_res = ollama.list()
        models_list = getattr(models_res, "models", models_res)
        names = []
        if isinstance(models_list, list):
            for m in models_list:
                name = m.model if hasattr(m, "model") else (m.get("model", "") if isinstance(m, dict) else "")
                if name:
                    names.append(name)
        if "model" in names or any(n.startswith("model:") for n in names):
            return "model"

        # Filter out embedding and vision models for standard text LLM tasks
        text_models = [
            n for n in names
            if "embed" not in n.lower() and not any(v in n.lower() for v in ["vision", "llava", "minicpm", "moondream"])
        ]

        for preferred in ["phi4-mini", "phi4", "qwen"]:
            for name in text_models:
                if name == preferred or name.startswith(preferred + ":"):
                    return name

        if text_models:
            return text_models[0]

        gen_models = [n for n in names if "embed" not in n.lower()]
        if gen_models:
            return gen_models[0]
    except Exception:
        pass
    return "phi4-mini"



LLM_MODEL = resolve_llm_model()

EMBED_MODEL = os.getenv("ANVIL_EMBED_MODEL", "nomic-embed-text")


CHUNK_TARGET_TOKENS = int(os.getenv("ANVIL_CHUNK_TOKENS", "300"))

CHUNK_OVERLAP_TOKENS = int(os.getenv("ANVIL_CHUNK_OVERLAP", "50"))

CHARS_PER_TOKEN = 4


RAG_TOP_K = int(os.getenv("ANVIL_RAG_TOP_K", "3"))


CHROMA_PATH = os.getenv("ANVIL_CHROMA_PATH", "./data/chroma_db")

COLLECTION_NAME = os.getenv("ANVIL_COLLECTION", "documents")


QUIZ_HISTORY_PATH = os.getenv("ANVIL_QUIZ_HISTORY", "./data/quiz_history/history.json")
