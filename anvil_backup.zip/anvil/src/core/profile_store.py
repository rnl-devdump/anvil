# src/core/profile_store.py
import json
import os

from src.core.config import CHROMA_PATH

PROFILE_FILE_PATH = os.path.join(os.path.dirname(CHROMA_PATH), "profile", "profile.json")


class ProfileStore:

    def __init__(self, filepath: str = PROFILE_FILE_PATH):
        self.filepath = filepath
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        self.data: dict = self._load()

    def _load(self) -> dict:
        default_profile = {
            "name": "Raven Neil Ocampo",
            "course": "Domain Course 1",
            "instructor": "Mr. Julius Caesar Mamaril",
            "avatar_path": ""
        }
        if not os.path.exists(self.filepath):
            self._save_raw(default_profile)
            return default_profile

        try:
            with open(self.filepath, encoding="utf-8") as f:
                loaded = json.load(f)
                default_profile.update(loaded)
                return default_profile
        except Exception:
            return default_profile

    def _save_raw(self, data: dict) -> None:
        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def save(self) -> None:
        self._save_raw(self.data)

    @property
    def name(self) -> str:
        return self.data.get("name", "Raven Neil Ocampo")

    @name.setter
    def name(self, val: str) -> None:
        self.data["name"] = val.strip()
        self.save()

    @property
    def avatar_path(self) -> str:
        return self.data.get("avatar_path", "")

    @avatar_path.setter
    def avatar_path(self, val: str) -> None:
        self.data["avatar_path"] = val.strip()
        self.save()

    @property
    def course(self) -> str:
        return self.data.get("course", "Domain Course 1")

    @property
    def instructor(self) -> str:
        return self.data.get("instructor", "Mr. Julius Caesar Mamaril")
