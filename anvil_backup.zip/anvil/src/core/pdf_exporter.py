# src/core/pdf_exporter.py
import os
import random
import fitz  # PyMuPDF

LOGO_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "logo.png")
PSU_LOGO_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "psu.png")


def export_quiz_to_pdf(title: str, questions: list[dict], output_path: str, profile=None) -> str:
    """
    Generates a high-quality printable PDF exam sheet matching the PSU quiz module format:
    - Upper Left: Pangasinan State University / College of Computing Sciences header & green subject bar
    - Upper Right: Official system logo image
    - Metadata block with 'BASED ON: <title>'
    - General Instructions box
    - 4 Structured Test Tables:
      TEST I: TRUE OR FALSE
      TEST II: MATCHING TYPE
      TEST III: IDENTIFICATION
      TEST IV: MULTIPLE CHOICE
    - Page footer with '1 | Page', '2 | Page', etc.
    - End of PDF signature block with 'Prepared by: Raven Ocampo'
    - Complete Answer Key section
    """
    if not questions:
        # Fallback question set if questions list is empty
        questions = [
            {"type": "TRUE_FALSE", "question": "Clustering is an unsupervised machine learning technique.", "answer": True},
            {"type": "TRUE_FALSE", "question": "DBSCAN requires defining the number of clusters beforehand.", "answer": False},
            {
                "type": "MATCHING",
                "question": "Match key clustering terms with their descriptions:",
                "pairs": [
                    {"premise": "K-means", "response": "Partitioning algorithm using cluster centroids"},
                    {"premise": "DBSCAN", "response": "Density-based clustering detecting noise points"},
                    {"premise": "Dendrogram", "response": "Tree diagram representing hierarchical clustering"},
                ]
            },
            {"type": "IDENTIFICATION", "question": "The clustering algorithm that creates a tree-like hierarchy of clusters.", "answer": "Agglomerative Clustering"},
            {"type": "IDENTIFICATION", "question": "The metric used to evaluate clustering compactness without ground truth.", "answer": "Silhouette Score"},
            {
                "type": "MULTIPLE_CHOICE",
                "question": "Which algorithm is best suited for recovering complex non-spherical cluster shapes?",
                "choices": ["K-means", "DBSCAN", "Linear Regression", "PCA"],
                "answer": "DBSCAN"
            },
            {
                "type": "MULTIPLE_CHOICE",
                "question": "What does an Adjusted Rand Index (ARI) score of 1.0 indicate?",
                "choices": ["Perfect match with ground truth", "Random cluster assignments", "High overlapping clusters", "Undefined metric"],
                "answer": "Perfect match with ground truth"
            }
        ]

    doc = fitz.open()
    width, height = 612.0, 792.0  # Standard Letter size
    margin = 36.0
    content_width = width - 2 * margin
    page_num = 1

    page = doc.new_page(width=width, height=height)
    y = margin

    def draw_footer(target_page, p_num):
        footer_text = f"{p_num} | P a g e"
        target_page.insert_text(
            (width - margin - 60, height - 24),
            footer_text,
            fontsize=10,
            fontname="helv",
            color=(0.2, 0.2, 0.2)
        )

    def check_space(needed: float):
        nonlocal page, y, page_num
        if y + needed > height - 40.0:
            draw_footer(page, page_num)
            page_num += 1
            page = doc.new_page(width=width, height=height)
            y = margin + 15.0

    # --- 1. HEADER SECTION (Page 1) ---
    # Top Left PSU Logo
    psu_logo_size = 65.0
    if os.path.exists(PSU_LOGO_PATH):
        psu_logo_rect = fitz.Rect(margin, y, margin + psu_logo_size, y + psu_logo_size)
        try:
            page.insert_image(psu_logo_rect, filename=PSU_LOGO_PATH)
        except Exception:
            pass

    # Institution Text (shifted right to accommodate PSU logo)
    inst_header = [
        ("Pangasinan State University", 12, True, (0.0, 0.3, 0.6)),
        ("COLLEGE OF COMPUTING SCIENCES", 10, True, (0.1, 0.1, 0.1)),
        ("Lingayen Campus", 9, False, (0.2, 0.2, 0.2)),
        ("Alvear St. Lingayen Pangasinan, 2401", 8.5, False, (0.3, 0.3, 0.3)),
    ]
    header_x = margin + psu_logo_size + 10.0
    header_y = y
    for txt, fsize, is_bold, color_rgb in inst_header:
        page.insert_text(
            (header_x, header_y + fsize),
            txt,
            fontsize=fsize,
            fontname="hebo" if is_bold else "helv",
            color=color_rgb
        )
        header_y += fsize + 3.0

    # Top Right System Logo Image
    if os.path.exists(LOGO_PATH):
        logo_rect = fitz.Rect(width - margin - 65, y, width - margin, y + 65)
        try:
            page.insert_image(logo_rect, filename=LOGO_PATH)
        except Exception:
            pass

    y = max(header_y + 6, y + 70)

    y += 10.0

    # Student Info Metadata Block
    info_lines = [
        "Name :_______________________________________________________________________________ DATE/TIME/ROOM:__________________",
        "Year/Section: III-BSCS-A________________________________________________________________________________",
    ]
    for line in info_lines:
        page.insert_text((margin, y + 9), line, fontsize=9, fontname="hebo", color=(0.1, 0.1, 0.1))
        y += 15.0

    # Formatted Title: BASED ON: ...
    clean_title = title.replace("BASED ON:", "").strip()
    if not clean_title or clean_title == "Quiz Document":
        clean_title = "DC1 - STUDY GUIDE 6 [MODULE #6] 'CLUSTERING'"
    title_display = f"BASED ON: {clean_title}"

    page.insert_text((margin, y + 9), title_display[:75], fontsize=9, fontname="hebo", color=(0.1, 0.1, 0.1))
    page.insert_text((width - margin - 140, y + 9), "Score:_____________________", fontsize=9, fontname="hebo", color=(0.1, 0.1, 0.1))
    y += 18.0

    # General Instruction Box
    inst_box_rect = fitz.Rect(margin, y, width - margin, y + 28)
    page.draw_rect(inst_box_rect, fill=(0.98, 0.98, 0.98), color=(0.2, 0.2, 0.2), width=0.8)
    inst_content = (
        "GENERAL INSTRUCTION: Strictly NO ERASURES of any kind. Use only the space provided for your answers. "
        "Ensure that your answers are clear, legible, and correctly spelled. The use of mobile phones or online references is not allowed."
    )
    page.insert_textbox(
        fitz.Rect(margin + 4, y + 3, width - margin - 4, y + 26),
        inst_content,
        fontsize=7.5,
        fontname="hebo",
        color=(0.1, 0.1, 0.1),
    )
    y += 34.0


    # --- 2. CATEGORIZE QUESTIONS INTO THE 4 TESTS ---
    # Filter out any questions with empty/blank question text
    questions = [q for q in questions if str(q.get("question", "")).strip()]

    tf_list = [q for q in questions if q.get("type") == "TRUE_FALSE"]
    matching_list = [q for q in questions if q.get("type") == "MATCHING"]
    id_list = [q for q in questions if q.get("type") in ("IDENTIFICATION", "ENUMERATION", "PARAGRAPH")]
    mc_list = [q for q in questions if q.get("type") == "MULTIPLE_CHOICE"]
    ps_list = [q for q in questions if q.get("type") == "PROGRAM_SOLVING"]

    # Synthesize fallback items if any section has 0 questions
    if not tf_list:
        tf_list = [
            {"type": "TRUE_FALSE", "question": "Clustering is a supervised learning task where response variables are available.", "answer": False},
            {"type": "TRUE_FALSE", "question": "The K-means algorithm finishes when instance assignments no longer change.", "answer": True},
            {"type": "TRUE_FALSE", "question": "Agglomerative clustering starts by declaring each point its own cluster.", "answer": True},
            {"type": "TRUE_FALSE", "question": "DBSCAN requires the user to set the number of clusters a priori.", "answer": False},
            {"type": "TRUE_FALSE", "question": "A dendrogram is a visualization tool for hierarchical clustering.", "answer": True},
        ]
    if not matching_list:
        matching_list = [
            {
                "type": "MATCHING",
                "question": "Match each key term with its corresponding description:",
                "pairs": [
                    {"premise": "K-means", "response": "Merges clusters to minimize variance within all clusters."},
                    {"premise": "DBSCAN", "response": "Density-based algorithm that captures complex shapes."},
                    {"premise": "Ward", "response": "Linkage criterion merging clusters with smallest variance."},
                    {"premise": "Dendrogram", "response": "Visualization showing the journey of merging clusters."},
                    {"premise": "Silhouette Score", "response": "A metric for evaluating clustering compactness."},
                ]
            }
        ]
    if not id_list:
        id_list = [
            {"type": "IDENTIFICATION", "question": "The task of partitioning a data set into groups.", "answer": "Clustering"},
            {"type": "IDENTIFICATION", "question": "The default linkage criterion in scikit-learn for Agglomerative Clustering.", "answer": "ward"},
            {"type": "IDENTIFICATION", "question": "The type of clustering that produces a hierarchy and can be visualized with a dendrogram.", "answer": "Hierarchical Clustering"},
            {"type": "IDENTIFICATION", "question": "This clustering algorithm allows for the detection of noise points.", "answer": "DBSCAN"},
        ]
    if not mc_list:
        mc_list = [
            {
                "type": "MULTIPLE_CHOICE",
                "question": "Which algorithm is best suited for recovering clusters with complex shapes?",
                "choices": ["K-means", "DBSCAN", "Linear Regression", "Ordinary Least Squares"],
                "answer": "DBSCAN"
            },
            {
                "type": "MULTIPLE_CHOICE",
                "question": "What is the output of a clustering algorithm for each data point?",
                "choices": ["A continuous target value", "A cluster label (number)", "A Boolean True/False", "A probability density"],
                "answer": "A cluster label (number)"
            },
            {
                "type": "MULTIPLE_CHOICE",
                "question": "In Agglomerative Clustering, which linkage criterion merges clusters based on smallest maximum distance?",
                "choices": ["average", "complete", "ward", "k-neighbors"],
                "answer": "complete"
            }
        ]


    def draw_section_header(title_text: str, subtitle_text: str):
        nonlocal y
        check_space(38.0)
        # Yellow section banner
        banner_rect = fitz.Rect(margin, y, width - margin, y + 16)
        page.draw_rect(banner_rect, fill=(1.0, 0.92, 0.0), color=(0.8, 0.7, 0.0))
        page.insert_text((margin + 6, y + 11), title_text, fontsize=9.5, fontname="hebo", color=(0.0, 0.0, 0.0))
        y += 19.0
        # Instructions line
        page.insert_text((margin, y + 9), f"📌 Instructions: {subtitle_text}", fontsize=8.5, fontname="heit", color=(0.15, 0.15, 0.15))
        y += 14.0


    # --- TEST I: TRUE OR FALSE ---
    draw_section_header(
        f"TEST I: TRUE OR FALSE ({len(tf_list)} Questions {len(tf_list)} × 1 point)",
        "Read each statement in the table below and determine whether it is True or False. Write your answer in the Answer column."
    )
    # Table Header
    col_w = [30.0, 410.0, 100.0]
    headers = ["No.", "Statement", "Answer"]

    check_space(20.0)
    page.draw_rect(fitz.Rect(margin, y, width - margin, y + 16), fill=(0.9, 0.9, 0.9), color=(0.0, 0.0, 0.0))
    x_curr = margin
    for i, h_txt in enumerate(headers):
        page.insert_text((x_curr + 4, y + 11), h_txt, fontsize=8.5, fontname="hebo", color=(0.0, 0.0, 0.0))
        x_curr += col_w[i]
    y += 16.0

    for idx, q in enumerate(tf_list, 1):
        q_text = str(q.get("question", ""))
        chars_per_line = 60
        lines = max(1, len(q_text) // chars_per_line + 1)
        row_h = max(20.0, lines * 14.0 + 8.0)
        check_space(row_h)

        row_rect = fitz.Rect(margin, y, width - margin, y + row_h)
        page.draw_rect(row_rect, color=(0.0, 0.0, 0.0), width=0.5)
        page.draw_line(fitz.Point(margin + col_w[0], y), fitz.Point(margin + col_w[0], y + row_h), color=(0.0, 0.0, 0.0), width=0.5)
        page.draw_line(fitz.Point(width - margin - col_w[2], y), fitz.Point(width - margin - col_w[2], y + row_h), color=(0.0, 0.0, 0.0), width=0.5)

        page.insert_text((margin + 8, y + 12), str(idx), fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        page.insert_textbox(fitz.Rect(margin + col_w[0] + 4, y + 2, margin + col_w[0] + col_w[1] - 4, y + row_h - 2), q_text, fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        y += row_h

    y += 14.0


    # --- TEST II: MATCHING TYPE ---
    matching_pairs = []
    for mq in matching_list:
        pairs = mq.get("pairs", [])
        for p in pairs:
            if isinstance(p, dict):
                matching_pairs.append((p.get("premise", ""), p.get("response", "")))

    if matching_pairs:
        draw_section_header(
            f"TEST II: MATCHING TYPE ({len(matching_pairs)} Questions {len(matching_pairs)} × 1 point)",
            "Match each key term in Column A with its corresponding description in Column B by writing the correct letter in the MATCH Column."
        )

        # Shuffle descriptions and assign letters for the reference list
        shuffled_responses = [p[1] for p in matching_pairs]
        random.shuffle(shuffled_responses)
        letters = [chr(65 + i) for i in range(len(shuffled_responses))]
        desc_map = {resp: let for let, resp in zip(letters, shuffled_responses)}

        # --- Description Reference Box (Column B choices shown separately) ---
        check_space(16.0 + 13.0 * len(shuffled_responses) + 8.0)
        page.insert_text((margin, y + 10), "Column B (Descriptions):", fontsize=8.5, fontname="hebo", color=(0.0, 0.0, 0.0))
        y += 14.0
        for let, desc in zip(letters, shuffled_responses):
            page.insert_text((margin + 12, y + 10), f"{let}. {desc}", fontsize=8.5, fontname="helv", color=(0.1, 0.1, 0.1))
            y += 13.0
        y += 8.0

        # --- Matching Table (Column A + blank Match column, descriptions left blank) ---
        col_w_m = [30.0, 310.0, 200.0]
        headers_m = ["No.", "Column A (Key Terms)", "Match"]

        check_space(20.0)
        page.draw_rect(fitz.Rect(margin, y, width - margin, y + 16), fill=(0.9, 0.9, 0.9), color=(0.0, 0.0, 0.0))
        x_curr = margin
        for i, h_txt in enumerate(headers_m):
            page.insert_text((x_curr + 4, y + 11), h_txt, fontsize=8.5, fontname="hebo", color=(0.0, 0.0, 0.0))
            x_curr += col_w_m[i]
        y += 16.0

        for idx, (premise, resp) in enumerate(matching_pairs, 1):
            chars_per_line = 45
            lines = max(1, len(premise) // chars_per_line + 1)
            row_h = max(20.0, lines * 14.0 + 8.0)
            check_space(row_h)

            row_rect = fitz.Rect(margin, y, width - margin, y + row_h)
            page.draw_rect(row_rect, color=(0.0, 0.0, 0.0), width=0.5)

            # Draw vertical column lines
            x1 = margin + col_w_m[0]
            x2 = x1 + col_w_m[1]
            for vx in (x1, x2):
                page.draw_line(fitz.Point(vx, y), fitz.Point(vx, y + row_h), color=(0.0, 0.0, 0.0), width=0.5)

            page.insert_text((margin + 8, y + 13), str(idx), fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
            page.insert_textbox(fitz.Rect(margin + col_w_m[0] + 4, y + 2, x2 - 4, y + row_h - 2), premise, fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
            # Match column left BLANK for students to fill in
            y += row_h

        y += 14.0


    # --- TEST III: IDENTIFICATION ---
    draw_section_header(
        f"TEST III: IDENTIFICATION ({len(id_list)} Questions {len(id_list)} × 2 point)",
        "Read each question carefully and write the correct term or phrase that best fits the statement. Write only your answer in the Answer column."
    )
    col_w_id = [30.0, 410.0, 100.0]
    headers_id = ["No.", "Sentence", "Answer"]

    check_space(20.0)
    page.draw_rect(fitz.Rect(margin, y, width - margin, y + 16), fill=(0.9, 0.9, 0.9), color=(0.0, 0.0, 0.0))
    x_curr = margin
    for i, h_txt in enumerate(headers_id):
        page.insert_text((x_curr + 4, y + 11), h_txt, fontsize=8.5, fontname="hebo", color=(0.0, 0.0, 0.0))
        x_curr += col_w_id[i]
    y += 16.0

    for idx, q in enumerate(id_list, 1):
        q_text = str(q.get("question", ""))
        chars_per_line = 60
        lines = max(1, len(q_text) // chars_per_line + 1)
        row_h = max(20.0, lines * 14.0 + 8.0)
        check_space(row_h)

        row_rect = fitz.Rect(margin, y, width - margin, y + row_h)
        page.draw_rect(row_rect, color=(0.0, 0.0, 0.0), width=0.5)
        page.draw_line(fitz.Point(margin + col_w_id[0], y), fitz.Point(margin + col_w_id[0], y + row_h), color=(0.0, 0.0, 0.0), width=0.5)
        page.draw_line(fitz.Point(width - margin - col_w_id[2], y), fitz.Point(width - margin - col_w_id[2], y + row_h), color=(0.0, 0.0, 0.0), width=0.5)

        page.insert_text((margin + 8, y + 12), str(idx), fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        page.insert_textbox(fitz.Rect(margin + col_w_id[0] + 4, y + 2, margin + col_w_id[0] + col_w_id[1] - 4, y + row_h - 2), q_text, fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        y += row_h

    y += 14.0


    # --- TEST IV: MULTIPLE CHOICE ---
    draw_section_header(
        f"TEST IV: MULTIPLE CHOICE ({len(mc_list)} Questions {len(mc_list)} × 1 point)",
        "Read each question carefully and choose the best answer. Write your answer in the ANSWER COLUMN."
    )
    col_w_mc = [30.0, 230.0, 200.0, 80.0]
    headers_mc = ["No.", "Question", "Options", "Answer"]

    check_space(20.0)
    page.draw_rect(fitz.Rect(margin, y, width - margin, y + 16), fill=(0.9, 0.9, 0.9), color=(0.0, 0.0, 0.0))
    x_curr = margin
    for i, h_txt in enumerate(headers_mc):
        page.insert_text((x_curr + 4, y + 11), h_txt, fontsize=8.5, fontname="hebo", color=(0.0, 0.0, 0.0))
        x_curr += col_w_mc[i]
    y += 16.0

    for idx, q in enumerate(mc_list, 1):
        q_text = str(q.get("question", ""))
        choices = q.get("choices", ["Option A", "Option B", "Option C", "Option D"])
        options_text = "\n".join([f"{chr(65+c_i)}. {choice}" for c_i, choice in enumerate(choices[:4])])

        q_lines = max(1, len(q_text) // 45 + 1)
        opt_lines = sum(max(1, len(str(c)) // 40 + 1) for c in choices[:4])
        lines_needed = max(q_lines, opt_lines)
        row_h = max(52.0, lines_needed * 14.0 + 10.0)
        check_space(row_h)

        row_rect = fitz.Rect(margin, y, width - margin, y + row_h)
        page.draw_rect(row_rect, color=(0.0, 0.0, 0.0), width=0.5)

        x1 = margin + col_w_mc[0]
        x2 = x1 + col_w_mc[1]
        x3 = x2 + col_w_mc[2]
        for vx in (x1, x2, x3):
            page.draw_line(fitz.Point(vx, y), fitz.Point(vx, y + row_h), color=(0.0, 0.0, 0.0), width=0.5)

        page.insert_text((margin + 8, y + 14), str(idx), fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        page.insert_textbox(fitz.Rect(x1 + 4, y + 4, x2 - 4, y + row_h - 4), q_text, fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
        page.insert_textbox(fitz.Rect(x2 + 4, y + 4, x3 - 4, y + row_h - 4), options_text, fontsize=8.0, fontname="helv", color=(0.0, 0.0, 0.0))
        y += row_h

    y += 24.0

    # --- TEST V: PROGRAM SOLVING ---
    if ps_list:
        draw_section_header(
            f"TEST V: PROGRAM SOLVING ({len(ps_list)} Questions {len(ps_list)} × 5 points)",
            "Analyze the following programs. Provide the correct code statements in the CORRECT CODES column to produce the given OUTPUT."
        )
        col_w_ps = [30.0, 210.0, 150.0, 150.0]
        headers_ps = ["No.", "PROGRAMS TO BE SOLVE", "CORRECT CODES (Descriptions)", "OUTPUT"]

        check_space(20.0)
        page.draw_rect(fitz.Rect(margin, y, width - margin, y + 16), fill=(0.9, 0.9, 0.9), color=(0.0, 0.0, 0.0))
        x_curr = margin
        for i, h_txt in enumerate(headers_ps):
            page.insert_text((x_curr + 4, y + 11), h_txt, fontsize=7.5, fontname="hebo", color=(0.0, 0.0, 0.0))
            x_curr += col_w_ps[i]
        y += 16.0

        for idx, q in enumerate(ps_list, 1):
            q_code = str(q.get("question", ""))
            out_text = str(q.get("output", ""))
            
            # Approximate height needed based on line count of code/output and wrapping
            q_lines = sum(max(1, len(line) // 35 + 1) for line in q_code.split("\n"))
            out_lines = sum(max(1, len(line) // 25 + 1) for line in out_text.split("\n"))
            lines_needed = max(q_lines, out_lines, 3) + 2
            row_h = max(52.0, lines_needed * 12.0)
            
            check_space(row_h)

            row_rect = fitz.Rect(margin, y, width - margin, y + row_h)
            page.draw_rect(row_rect, color=(0.0, 0.0, 0.0), width=0.5)

            x1 = margin + col_w_ps[0]
            x2 = x1 + col_w_ps[1]
            x3 = x2 + col_w_ps[2]
            for vx in (x1, x2, x3):
                page.draw_line(fitz.Point(vx, y), fitz.Point(vx, y + row_h), color=(0.0, 0.0, 0.0), width=0.5)

            page.insert_text((margin + 8, y + 14), str(idx), fontsize=8.5, fontname="helv", color=(0.0, 0.0, 0.0))
            
            # Code snippet
            page.insert_textbox(fitz.Rect(x1 + 4, y + 4, x2 - 4, y + row_h - 4), q_code, fontsize=8.0, fontname="Courier", color=(0.0, 0.0, 0.0))
            
            # CORRECT CODES column is left BLANK intentionally for the student to write in.
            
            # Output column
            page.insert_textbox(fitz.Rect(x3 + 4, y + 4, width - margin - 4, y + row_h - 4), out_text, fontsize=8.0, fontname="Courier", color=(0.0, 0.0, 0.0))
            
            y += row_h

        y += 24.0


    # --- 3. END OF THE PDF SIGNATURE BLOCK ---
    check_space(110.0)

    # Prepared by: Raven Ocampo
    page.insert_text((margin, y + 12), "Auto-Prepared by:", fontsize=9, fontname="hebi", color=(0.1, 0.1, 0.1))
    page.insert_text((margin + 40, y + 32), "RAVEN OCAMPO", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
    page.insert_text((margin + 20, y + 44), "Developer", fontsize=8.5, fontname="helv", color=(0.2, 0.2, 0.2))

    draw_footer(page, page_num)


    # --- 4. ANSWER KEY SECTION (Final Page) ---
    page_num += 1
    page = doc.new_page(width=width, height=height)
    y = margin + 10.0

    page.insert_text((margin, y + 14), "ANSWER KEY — STUDENT STUDY BUDDY SYSTEM", fontsize=14, fontname="hebo", color=(0.0, 0.3, 0.6))
    y += 22.0
    page.draw_line(fitz.Point(margin, y), fitz.Point(width - margin, y), color=(0.7, 0.7, 0.7), width=1.0)
    y += 18.0

    # Answer Key: TEST I
    page.insert_text((margin, y + 10), "TEST I: TRUE OR FALSE", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
    y += 16.0
    for idx, q in enumerate(tf_list, 1):
        ans_val = "True" if q.get("answer") is True or str(q.get("answer")).lower() == "true" else "False"
        page.insert_text((margin + 12, y + 10), f"{idx}. {ans_val}", fontsize=9, fontname="helv", color=(0.1, 0.1, 0.1))
        y += 14.0
    y += 10.0

    # Answer Key: TEST II
    if matching_pairs:
        page.insert_text((margin, y + 10), "TEST II: MATCHING TYPE", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
        y += 16.0
        for idx, (premise, resp) in enumerate(matching_pairs, 1):
            corr_let = desc_map.get(resp, "A")
            page.insert_text((margin + 12, y + 10), f"{idx}. {corr_let} ({premise} = {resp})", fontsize=8.5, fontname="helv", color=(0.1, 0.1, 0.1))
            y += 14.0
        y += 10.0

    # Answer Key: TEST III
    page.insert_text((margin, y + 10), "TEST III: IDENTIFICATION", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
    y += 16.0
    for idx, q in enumerate(id_list, 1):
        ans_val = str(q.get("answer", ""))
        page.insert_text((margin + 12, y + 10), f"{idx}. {ans_val}", fontsize=9, fontname="helv", color=(0.1, 0.1, 0.1))
        y += 14.0
    y += 10.0

    # Answer Key: TEST IV
    page.insert_text((margin, y + 10), "TEST IV: MULTIPLE CHOICE", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
    y += 16.0
    for idx, q in enumerate(mc_list, 1):
        ans_val = str(q.get("answer", ""))
        choices = q.get("choices", [])
        letter = "A"
        for c_i, c in enumerate(choices[:4]):
            if str(c).strip().lower() == ans_val.strip().lower():
                letter = chr(65 + c_i)
                break
        page.insert_text((margin + 12, y + 10), f"{idx}. {letter} ({ans_val})", fontsize=9, fontname="helv", color=(0.1, 0.1, 0.1))
        y += 14.0

    y += 10.0

    # Answer Key: TEST V
    if ps_list:
        page.insert_text((margin, y + 10), "TEST V: PROGRAM SOLVING", fontsize=10, fontname="hebo", color=(0.0, 0.0, 0.0))
        y += 16.0
        for idx, q in enumerate(ps_list, 1):
            ans_val = str(q.get("answer", ""))
            
            # Multi-line answers might need more space
            lines = ans_val.split("\n")
            page.insert_text((margin + 12, y + 10), f"{idx}. ", fontsize=9, fontname="hebo", color=(0.1, 0.1, 0.1))
            
            text_y = y + 10
            for line in lines:
                page.insert_text((margin + 25, text_y), line, fontsize=9, fontname="Courier", color=(0.0, 0.4, 0.0))
                text_y += 12.0
            
            y = text_y + 4.0

    draw_footer(page, page_num)

    doc.save(output_path)
    doc.close()
    return output_path
