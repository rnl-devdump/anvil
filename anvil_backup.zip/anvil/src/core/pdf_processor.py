import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

# Configure Logging
logger = logging.getLogger("RAG-Ingest")
if not logger.handlers:
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(handler)

# ---------------------------------------------------------------------------
# PyMuPDF4LLM Import Check
# ---------------------------------------------------------------------------
PYMUPDF4LLM_AVAILABLE = False
try:
    import pymupdf4llm
    PYMUPDF4LLM_AVAILABLE = True
except ImportError:
    pass


class RobustPDFProcessor:
    """
    Streamlined PDF processing pipeline supporting PyMuPDF4LLM and Vision OCR.
    """
    MIN_CHUNK_WORDS = 15  # Minimum words for a chunk to be kept

    def __init__(self, max_tokens: int = 800, overlap_tokens: int = 50, min_char_threshold: int = 100):
        self.max_tokens = max_tokens
        self.overlap_tokens = overlap_tokens
        self.min_char_threshold = min_char_threshold
        self.chars_per_token = 4  # Consistent with config.CHARS_PER_TOKEN

    def process_with_pymupdfllm(self, pdf_path: str) -> Tuple[Optional[str], Optional[List[Dict[str, Any]]]]:
        """Extract Markdown text using PyMuPDF4LLM with cross-page chunking."""
        if not PYMUPDF4LLM_AVAILABLE:
            logger.error("[PyMuPDF4LLM] PyMuPDF4LLM engine requested but module is not available.")
            return None, None

        try:
            logger.info(f"[PyMuPDF4LLM] Processing document: {pdf_path}")
            page_data = pymupdf4llm.to_markdown(pdf_path, page_chunks=True)
            if isinstance(page_data, str):
                full_md = page_data
                chunks = self._chunk_text(full_md, pdf_path, page_num=1)
                return full_md, chunks

            # Build a list of (page_number, paragraph_text) tuples for cross-page chunking
            page_paragraphs: List[Tuple[int, str]] = []
            full_parts = []

            for page in page_data:
                if not isinstance(page, dict):
                    continue
                page_num = page.get("metadata", {}).get("page_number", 1)
                text = page.get("text", "").strip()

                if text:
                    full_parts.append(text)
                    for para in text.split("\n\n"):
                        para = para.strip()
                        if para:
                            page_paragraphs.append((page_num, para))

            full_markdown = "\n\n".join(full_parts)
            chunks = self._chunk_paragraphs(page_paragraphs, pdf_path, engine="pymupdfllm")
            return full_markdown, chunks

        except Exception as e:
            logger.error(f"[PyMuPDF4LLM] Extraction failed: {str(e)}")
            return None, None

    def process_with_vision(self, pdf_path: str, vision_model: Optional[str] = None) -> Tuple[Optional[str], Optional[List[Dict[str, Any]]]]:
        """Extract text from scanned/image PDFs by rendering pages and sending to an Ollama Vision model."""
        try:
            import fitz  # PyMuPDF
            import ollama

            if not vision_model:
                try:
                    res = ollama.list()
                    models_list = getattr(res, "models", res)
                    names = [m.model if hasattr(m, "model") else m.get("model", "") for m in models_list]
                    vision_keywords = ["vision", "llava", "minicpm", "moondream", "qwen2-vl", "bakllava"]
                    vision_models = [n for n in names if any(k in n.lower() for k in vision_keywords)]
                    if vision_models:
                        vision_model = vision_models[0]
                except Exception:
                    pass

            if not vision_model:
                logger.info("[Vision] No vision model (e.g. llama3.2-vision, llava, minicpm-v) installed in Ollama.")
                return None, None

            logger.info(f"[Vision] Using vision model '{vision_model}' for scanned document: {pdf_path}")
            doc = fitz.open(pdf_path)
            extracted_pages = []

            for page_idx, page in enumerate(doc):
                pix = page.get_pixmap(dpi=150)
                img_bytes = pix.tobytes("png")

                response = ollama.chat(
                    model=vision_model,
                    messages=[{
                        "role": "user",
                        "content": "Transcribe all text from this scanned page image accurately into clean Markdown. Do not summarize or add meta commentary.",
                        "images": [img_bytes]
                    }]
                )
                page_text = response.get("message", {}).get("content", "").strip()
                extracted_pages.append({"page": page_idx + 1, "text": page_text})

            doc.close()
            full_markdown = "\n\n".join([p["text"] for p in extracted_pages if p["text"]])

            page_paragraphs: List[Tuple[int, str]] = []
            for p in extracted_pages:
                if not p["text"]:
                    continue
                for para in p["text"].split("\n\n"):
                    para = para.strip()
                    if para:
                        page_paragraphs.append((p["page"], para))

            engine_label = f"vision ({vision_model})"
            chunks = self._chunk_paragraphs(page_paragraphs, pdf_path, engine=engine_label) if page_paragraphs else []

            return full_markdown, chunks

        except Exception as e:
            logger.error(f"[Vision] Processing failed: {e}")
            return None, None

    def _chunk_paragraphs(
        self,
        page_paragraphs: List[Tuple[int, str]],
        pdf_path: str,
        engine: str = "pymupdfllm",
    ) -> List[Dict[str, Any]]:
        """
        Character-based chunker with overlap operating on (page_num, paragraph)
        tuples to ensure cross-page continuity.
        """
        target_chars = self.max_tokens * self.chars_per_token
        overlap_chars = self.overlap_tokens * self.chars_per_token
        chunks: List[Dict[str, Any]] = []
        chunk_id = 0

        current_paras: List[str] = []
        current_pages: List[int] = []
        current_len = 0

        def _flush():
            nonlocal chunk_id
            chunk_text = "\n\n".join(current_paras).strip()
            if len(chunk_text.split()) >= self.MIN_CHUNK_WORDS:
                primary_page = max(set(current_pages), key=current_pages.count) if current_pages else 1
                chunks.append({
                    "chunk_id": chunk_id,
                    "text": chunk_text,
                    "metadata": {"source": str(pdf_path), "engine": engine, "page": primary_page}
                })
                chunk_id += 1

        for page_num, para in page_paragraphs:
            para_chars = len(para)

            if current_len + para_chars > target_chars and current_paras:
                _flush()

                overlap_paras: List[Tuple[int, str]] = []
                overlap_len = 0
                for p_text, p_page in zip(reversed(current_paras), reversed(current_pages)):
                    if overlap_len + len(p_text) > overlap_chars:
                        break
                    overlap_paras.append((p_page, p_text))
                    overlap_len += len(p_text)
                overlap_paras.reverse()

                current_paras = [t for _, t in overlap_paras]
                current_pages = [pg for pg, _ in overlap_paras]
                current_len = overlap_len

            current_paras.append(para)
            current_pages.append(page_num)
            current_len += para_chars

        if current_paras:
            _flush()

        return chunks

    def _chunk_text(self, text: str, pdf_path: str, page_num: int = 1, engine: str = "pymupdfllm") -> List[Dict[str, Any]]:
        """Convenience wrapper: chunk a plain text string into (page_num, paragraph) tuples."""
        paragraphs = [(page_num, p.strip()) for p in text.split("\n\n") if p.strip()]
        return self._chunk_paragraphs(paragraphs, pdf_path, engine=engine)

    def is_valid_output(self, markdown_text: Optional[str]) -> bool:
        """Validates extracted text quality."""
        if not markdown_text or len(markdown_text.strip()) < self.min_char_threshold:
            return False
        return True

    def process(self, pdf_path: str, engine: str = "pymupdfllm") -> Dict[str, Any]:
        """
        Executes primary ingestion via PyMuPDF4LLM or Vision OCR.
        """
        pdf_path = str(Path(pdf_path).resolve())
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"File not found: {pdf_path}")

        engine_key = engine.lower()
        engine_used = engine_key
        markdown_text, chunks = None, None

        if engine_key in ("vision", "ocr"):
            markdown_text, chunks = self.process_with_vision(pdf_path)
            engine_used = "vision"
        else:
            markdown_text, chunks = self.process_with_pymupdfllm(pdf_path)
            engine_used = "pymupdfllm"

        # Fallback ladder: try Vision OCR if PyMuPDF4LLM fails
        if not self.is_valid_output(markdown_text) and engine_used != "vision":
            logger.warning("[Pipeline] PyMuPDF4LLM produced insufficient text. Triggering Vision OCR fallback...")
            markdown_text, chunks = self.process_with_vision(pdf_path)
            if self.is_valid_output(markdown_text):
                engine_used = "vision"

        if not self.is_valid_output(markdown_text):
            raise RuntimeError(f"Requested engine '{engine}' failed to extract text from {pdf_path}")

        return {
            "status": "success",
            "engine_used": engine_used,
            "file_path": pdf_path,
            "markdown": markdown_text,
            "chunks": chunks,
            "total_chunks": len(chunks) if chunks else 0
        }
