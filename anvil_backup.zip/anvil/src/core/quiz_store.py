# src/core/quiz_store.py
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from src.core.config import QUIZ_HISTORY_PATH


class _QuizEncoder(json.JSONEncoder):
    """Handles Pydantic BaseModel instances that may leak into records."""
    def default(self, o):
        if hasattr(o, "model_dump"):
            return o.model_dump()
        return super().default(o)


class QuizStore:

    def __init__(self, path: str = QUIZ_HISTORY_PATH):

        self.path = Path(path)

        self.path.parent.mkdir(parents=True, exist_ok=True)

        self._records: list[dict[str, Any]] = []

        self._load()


    def _load(self) -> None:

        if self.path.exists():

            try:

                with open(self.path, encoding="utf-8") as f:

                    self._records = json.load(f)

            except (json.JSONDecodeError, ValueError) as e:

                print(f"[WARN] Failed to load quiz history from {self.path}: {e}")

                corrupt_path = self.path.with_suffix(".corrupt")

                try:

                    self.path.replace(corrupt_path)

                except Exception:

                    pass

                self._records = []

                self._save()

        else:

            self._records = []

            self._save()


    def _save(self) -> None:

        tmp_path = self.path.with_suffix(".tmp")

        with open(tmp_path, "w", encoding="utf-8") as f:

            json.dump(self._records, f, indent=2, ensure_ascii=False, cls=_QuizEncoder)

        tmp_path.replace(self.path)


    @property
    def all(self) -> list[dict[str, Any]]:

        return list(reversed(self._records))


    def get(self, quiz_id: str) -> dict[str, Any] | None:

        for record in self._records:

            if record["id"] == quiz_id:

                return record

        return None


    def add(
        self,
        title: str,
        source: str,
        questions: list[dict[str, Any]],
    ) -> dict[str, Any]:

        record = {
            "id": uuid.uuid4().hex[:12],
            "title": title,
            "source": source,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "question_count": len(questions),
            "questions": questions,
        }

        self._records.append(record)

        self._save()

        return record


    def delete(self, quiz_id: str) -> bool:

        before = len(self._records)

        self._records = [r for r in self._records if r["id"] != quiz_id]

        if len(self._records) < before:

            self._save()

            return True

        return False

    def update_score(self, quiz_id: str, score_out_of_10: float) -> bool:
        for r in self._records:
            if r["id"] == quiz_id:
                r["last_score"] = round(score_out_of_10, 1)
                r["last_attempt_at"] = datetime.now(timezone.utc).isoformat()
                self._save()
                return True
        return False
