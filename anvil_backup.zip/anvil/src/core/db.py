# src/core/db.py
import os

import chromadb
import ollama

from src.core.config import CHROMA_PATH, COLLECTION_NAME, EMBED_MODEL, RAG_TOP_K
from src.core.file import File


class Db:

    def __init__(self):

        os.makedirs(CHROMA_PATH, exist_ok=True)

        self.client = chromadb.PersistentClient(path=CHROMA_PATH)

        self.collection = self.client.get_or_create_collection(name=COLLECTION_NAME)

        self._current_source: str | None = None


    def _embed_text(self, text: str) -> list[float]:

        response = ollama.embed(model=EMBED_MODEL, input=text)

        return response["embeddings"][0]


    def clear_document(self, source: str) -> None:
        """Remove prior chunks for the same source before re-embedding."""

        existing = self.collection.get(where={"source": source})

        if existing["ids"]:

            self.collection.delete(ids=existing["ids"])


    def embed(self, file_instance: File) -> int:

        chunks = file_instance.get_chunks()

        if not chunks:

            return 0


        source = file_instance.display_name

        self.clear_document(source)

        self._current_source = source


        # Prepare all valid texts
        cleaned_texts: list[str] = []
        valid_indices: list[int] = []
        for i, (page_num, text) in enumerate(chunks):
            cleaned = " ".join(text.replace("\n", " ").split()).strip()
            if len(cleaned) >= 10:
                cleaned_texts.append(cleaned)
                valid_indices.append(i)

        if not cleaned_texts:
            return 0

        # Batch embed all texts in a single Ollama call
        response = ollama.embed(model=EMBED_MODEL, input=cleaned_texts)
        vectors = response["embeddings"]

        # Bulk upsert into ChromaDB
        ids = [f"{source}_chunk_{valid_indices[j]}" for j in range(len(cleaned_texts))]
        metadatas = [{"page": chunks[valid_indices[j]][0], "source": source} for j in range(len(cleaned_texts))]

        self.collection.upsert(
            ids=ids,
            embeddings=vectors,
            documents=cleaned_texts,
            metadatas=metadatas,
        )

        return len(cleaned_texts)


    def query(self, question: str, n_results: int = RAG_TOP_K) -> list[str]:

        if self.collection.count() == 0:

            return []


        query_vector = self._embed_text(question)

        where = {"source": self._current_source} if self._current_source else None


        results = self.collection.query(
            query_embeddings=[query_vector],

            n_results=min(n_results, self.collection.count()),
            where=where,
        )


        documents = results.get("documents") or [[]]

        return [doc for doc in documents[0] if doc]


    @property

    def chunk_count(self) -> int:

        return self.collection.count()


    @property

    def current_source(self) -> str | None:

        return self._current_source
