# src/app_controller.py
import json
from typing import Callable

from customtkinter import filedialog

from src.core.db import Db
from src.core.file import File
from src.core.llm import LlmService
from src.core.profile_store import ProfileStore
from src.core.quiz_store import QuizStore
from src.core.schema import ParagraphEvaluation, QuizQuestion


class AppController:

    def __init__(self):

        self.db = Db()

        self.llm = LlmService()

        self.quiz_store = QuizStore()

        self.profile_store = ProfileStore()

        self.file: File | None = None

        self.quiz: list[QuizQuestion] = []

        self.active_quiz_id: str | None = None

        self.chat_history: list[dict] = []

        self.pdf_engine: str = "pymupdfllm"


    def set_pdf_engine(self, engine: str) -> None:

        self.pdf_engine = engine


    def load_file_path(self, filepath: str) -> None:

        self.file = File(filepath, pdf_engine=self.pdf_engine)

        self._load_and_embed()


    def open_file(self) -> str | None:

        filepath = filedialog.askopenfilename(
            title="Upload your materials",
            filetypes=[
                ("PDF files", "*.pdf"),
                ("Text files", "*.txt"),
                ("All files", "*.*"),
            ],
        )

        if not filepath:

            return None

        self.load_file_path(filepath)

        return filepath


    def load_pasted_text(self, text: str) -> None:

        cleaned = text.strip()

        if not cleaned:

            raise ValueError("Pasted text is empty.")

        self.file = File(filepath="NO_FILEPATH", raw_text=cleaned, pdf_engine=self.pdf_engine)

        self._load_and_embed()


    def _load_and_embed(self) -> None:

        if not self.file:

            return

        self.file.parse_file()

        count = self.db.embed(self.file)

        if count == 0:

            raise RuntimeError("No usable text chunks found in the document.")

        self.quiz = []

        self.active_quiz_id = None
        
        self.chat_history = []


    @property

    def is_loaded(self) -> bool:

        return self.file is not None and self.db.chunk_count > 0


    @property
    def document_label(self) -> str:

        if not self.file:

            return "No document loaded"

        chunks = len(self.file.get_chunks())

        return f"{self.file.display_name} — {chunks} chunks embedded"


    MIN_CHUNK_WORDS_FOR_QUIZ = 30

    def generate_quiz(
        self,
        on_progress: Callable[[int, int, str], None] | None = None,
        on_chunk_error: Callable[[int, str], None] | None = None,
        preferences: str = ""
    ) -> list[dict]:

        if not self.is_loaded or not self.file:
            raise RuntimeError("Load a document before generating a quiz.")

        chunks = self.file.get_chunks()
        self.quiz = []

        # Filter out chunks too small for meaningful quiz generation
        eligible_chunks = [
            (pg, txt) for pg, txt in chunks
            if len(txt.split()) >= self.MIN_CHUNK_WORDS_FOR_QUIZ
        ]
        if not eligible_chunks and chunks:
            # Fallback to using all chunks even if brief
            eligible_chunks = chunks

        total = len(eligible_chunks)

        if total == 0:
            # If no chunks at all, let AI generate relevant questions based on document title / topic
            doc_topic = self.file.display_name if self.file else "General Study Material"
            if on_progress:
                on_progress(1, 1, f"Synthesizing questions for topic: {doc_topic}")
            try:
                response = self.llm.generate_questions_for_chunk(
                    f"Subject/Topic: {doc_topic}. Please generate a complete quiz based on this subject. You MUST provide 4 questions of EACH type.",
                    preferences=preferences,
                    num_questions=16
                )
                self.quiz.extend(response.questions)
            except Exception as e:
                raise RuntimeError(f"Failed to generate AI questions: {e}")
        else:
            num_per_chunk = 4
            for index, (_page_num, chunk_text) in enumerate(eligible_chunks):
                if on_progress:
                    on_progress(index + 1, total, chunk_text[:80])

                try:
                    response = self.llm.generate_questions_for_chunk(
                        chunk_text,
                        preferences=preferences,
                        num_questions=num_per_chunk
                    )
                    self.quiz.extend(response.questions)
                except Exception as e:
                    if on_chunk_error:
                        on_chunk_error(index + 1, str(e))
                    continue

        if not self.quiz:
            # Ultimate fallback if chunk generation yielded nothing
            doc_topic = self.file.display_name if self.file else "Study Topic"
            response = self.llm.generate_questions_for_chunk(
                f"Subject: {doc_topic}. Generate high-quality quiz questions covering true/false, matching, identification, and multiple choice.",
                preferences=preferences,
                num_questions=16
            )
            self.quiz.extend(response.questions)

        # Ensure strict structure (backfill and convert if needed, and trim extras)
        self._enforce_strict_quiz_structure(on_progress=on_progress)

        # Deduplicate questions by normalized question text
        self._deduplicate_quiz()

        return [q.model_dump() if hasattr(q, "model_dump") else q for q in self.quiz]


    # Minimum required questions per type for a complete quiz export
    MIN_PER_TYPE = {
        "TRUE_FALSE": 10,
        "MATCHING": 10,      # At least 10 matching pairs total
        "IDENTIFICATION": 10,
        "MULTIPLE_CHOICE": 10,
        "PROGRAM_SOLVING": 5,
    }

    def _enforce_strict_quiz_structure(self, on_progress=None) -> None:
        """Categorizes questions, pools extras, converts them to missing types, and trims."""
        doc_topic = self.file.display_name if self.file else "Study Topic"
        
        context_text = ""
        if self.file:
            chunks = self.file.get_chunks()
            context_text = "\n".join(txt for _, txt in chunks[:3])

        quiz_dicts = []
        for q in self.quiz:
            if hasattr(q, "model_dump"):
                quiz_dicts.append(q.model_dump())
            else:
                quiz_dicts.append(q)
                
        # Filter out empty questions
        quiz_dicts = [d for d in quiz_dicts if str(d.get("question", "")).strip()]

        categorized = {k: [] for k in self.MIN_PER_TYPE}
        spares = []

        def get_matching_pairs_count():
            return sum(len(q.get("pairs", [])) for q in categorized["MATCHING"])

        # 1. Categorize and find spares
        for d in quiz_dicts:
            q_type = d.get("type")
            if q_type == "MATCHING":
                needed = self.MIN_PER_TYPE["MATCHING"] - get_matching_pairs_count()
                if needed > 0:
                    pairs = d.get("pairs", [])
                    taken = pairs[:needed]
                    d["pairs"] = taken
                    categorized["MATCHING"].append(d)
                else:
                    spares.append(d)
            elif q_type in categorized:
                if len(categorized[q_type]) < self.MIN_PER_TYPE[q_type]:
                    categorized[q_type].append(d)
                else:
                    spares.append(d)
            else:
                spares.append(d)

        # 2. Fill deficits by converting spares or generating
        for q_type, min_count in self.MIN_PER_TYPE.items():
            retries = 3
            while retries > 0:
                if q_type == "MATCHING":
                    current_count = get_matching_pairs_count()
                    if current_count >= min_count:
                        break
                    deficit = 1 # Generate 1 matching question
                else:
                    current_count = len(categorized[q_type])
                    if current_count >= min_count:
                        break
                    deficit = min_count - current_count
                    
                if on_progress:
                    on_progress(0, 0, f"Converting/Generating {deficit} {q_type} questions...")

                source_questions = []
                while spares and len(source_questions) < deficit:
                    source_questions.append(spares.pop(0))

                existing_texts = [str(d.get("question", "")) for d in categorized[q_type]]

                try:
                    response = self.llm.fill_and_convert_questions(
                        topic=doc_topic,
                        question_type=q_type,
                        count=deficit,
                        source_questions=source_questions,
                        existing_questions=existing_texts,
                        context_text=context_text,
                    )
                    for q in response.questions:
                        q_dict = q.model_dump() if hasattr(q, "model_dump") else dict(q)
                        if not str(q_dict.get("question", "")).strip():
                            continue
                            
                        gen_type = q_dict.get("type")
                        if gen_type == "MATCHING" and q_type == "MATCHING":
                            need = min_count - get_matching_pairs_count()
                            if need > 0:
                                pairs = q_dict.get("pairs", [])
                                taken = pairs[:need]
                                q_dict["pairs"] = taken
                                categorized["MATCHING"].append(q_dict)
                            else:
                                spares.append(q_dict)
                        elif gen_type in categorized and gen_type != "MATCHING":
                            if len(categorized[gen_type]) < self.MIN_PER_TYPE[gen_type]:
                                categorized[gen_type].append(q_dict)
                            else:
                                spares.append(q_dict)
                        else:
                            spares.append(q_dict)
                except Exception as e:
                    print(f"[Conversion/Backfill] Failed to generate {q_type}: {e}")
                    
                retries -= 1
                
        # 3. Assemble final strictly trimmed quiz
        final_quiz = []
        for q_type in self.MIN_PER_TYPE:
            if q_type == "MATCHING":
                final_matching = []
                pairs_accum = 0
                for mq in categorized[q_type]:
                    if pairs_accum >= self.MIN_PER_TYPE[q_type]:
                        break
                    need = self.MIN_PER_TYPE[q_type] - pairs_accum
                    pairs = mq.get("pairs", [])
                    if len(pairs) > need:
                        mq["pairs"] = pairs[:need]
                    final_matching.append(mq)
                    pairs_accum += len(mq.get("pairs", []))
                final_quiz.extend(final_matching)
            else:
                final_quiz.extend(categorized[q_type][:self.MIN_PER_TYPE[q_type]])
            
        self.quiz = final_quiz

    def _deduplicate_quiz(self) -> None:
        """Remove duplicate questions based on normalized question text."""
        seen = set()
        unique = []
        for q in self.quiz:
            q_dict = q.model_dump() if hasattr(q, "model_dump") else q
            q_text = str(q_dict.get("question", "")).strip().lower()
            if q_text and q_text not in seen:
                seen.add(q_text)
                unique.append(q)
        self.quiz = unique



    def save_quiz_to_history(self, questions: list[dict] | None = None) -> dict:

        payload = questions or [q.model_dump() for q in self.quiz]

        if not payload:

            raise RuntimeError("No quiz to save.")


        source = self.file.display_name if self.file else "Unknown"

        title = f"{source} ({len(payload)} Q)"

        record = self.quiz_store.add(title=title, source=source, questions=payload)

        self.active_quiz_id = record["id"]

        return record


    def update_quiz_score(self, quiz_id: str, score_out_of_10: float) -> None:
        self.quiz_store.update_score(quiz_id, score_out_of_10)

    def load_quiz_from_history(self, quiz_id: str) -> list[dict]:

        record = self.quiz_store.get(quiz_id)

        if not record:

            raise ValueError("Quiz not found in history.")

        self.active_quiz_id = quiz_id

        self.quiz = record["questions"]

        return self.quiz


    def export_active_quiz_to_pdf(self, filepath: str) -> str:
        from src.core.pdf_exporter import export_quiz_to_pdf

        questions = []
        if self.quiz:
            questions = [q.model_dump() if hasattr(q, "model_dump") else q for q in self.quiz]
        elif self.active_quiz_id:
            record = self.quiz_store.get(self.active_quiz_id)
            if record:
                questions = record.get("questions", [])

        if not questions:
            raise RuntimeError("No quiz available to export.")

        title = "Quiz Document"
        if self.active_quiz_id:
            record = self.quiz_store.get(self.active_quiz_id)
            if record:
                title = record.get("title", title)
        elif self.file:
            title = f"{self.file.display_name} ({len(questions)} Q)"

        return export_quiz_to_pdf(title, questions, filepath)


    def ask(self, question: str) -> tuple[str, list[str]]:

        cleaned = question.strip()

        if not cleaned:

            raise ValueError("Enter a question.")

        # Check for simple greetings or casual conversation
        greetings = {"hey", "hi", "hello", "good morning", "good afternoon", "good evening", "howdy", "sup", "yo", "thanks", "thank you"}
        clean_lower = cleaned.lower().strip(".,!?")
        if clean_lower in greetings or (len(clean_lower.split()) <= 2 and any(w in greetings for w in clean_lower.split())):
            reply = f"Hello {self.profile_store.name}! I'm Student Study Buddy System. Ask me any question about your materials!"
            self.chat_history.append({"role": "user", "content": cleaned})
            self.chat_history.append({"role": "assistant", "content": reply})
            return reply, []

        context_chunks = []
        if self.is_loaded:
            history_text = "\n".join([m["content"] for m in self.chat_history[-2:]]) if self.chat_history else ""
            query_text = f"{history_text}\n{cleaned}".strip()
            try:
                context_chunks = self.db.query(query_text)
            except Exception:
                context_chunks = []

        response = self.llm.answer_question(cleaned, context_chunks, chat_history=self.chat_history)

        self.chat_history.append({"role": "user", "content": cleaned})
        self.chat_history.append({"role": "assistant", "content": response.answer})

        return response.answer, context_chunks

    def clear_chat_history(self) -> None:
        self.chat_history = []


    def evaluate_paragraph(
        self, question: str, model_answer: str, user_answer: str
    ) -> ParagraphEvaluation:

        cleaned = user_answer.strip()

        if not cleaned:

            raise ValueError("Enter an answer before submitting.")

        return self.llm.evaluate_paragraph_answer(question, model_answer, cleaned)


    def quiz_as_json(self, indent: int = 2) -> str:

        if not self.quiz:

            return "[]"

        if isinstance(self.quiz[0], dict):

            payload = self.quiz
        else:

            payload = [q.model_dump() for q in self.quiz]

        return json.dumps(payload, indent=indent)
