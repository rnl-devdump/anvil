# anvil.py
from src.app import App

if __name__ == "__main__":
    App().run()
